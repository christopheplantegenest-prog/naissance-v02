// === DEBUT_SAUVEGARDE_COMPLETE ===
// v0.17.15 — SAUVEGARDE COMPLÈTE DE NAISSANCE : un seul fichier qui couvre les DEUX bases
// persistantes (naissance-memoire ET naissance-langage), pour survivre à un changement d'appareil,
// une réinstallation ou un passage APK <-> navigateur. NE REMPLACE PAS le format existant
// (transfert.js : { format:'naissance', ... }, memoire seule) : ce module ajoute un SECOND format,
// distinct et versionné séparément ({ format:'naissance-sauvegarde-complete', schema, ... }), lu et
// écrit par app/memoire/ecran.js SANS jamais casser l'ancien.
//
// EXCLUSIONS VOLONTAIRES (jamais dans le fichier produit) : clés API, configuration des
// fournisseurs, diagnostics techniques, brouillons -- tout cela vit dans localStorage
// (app/reglages/stockage.js et consorts), jamais lu par ce module. Les clés API devront être
// ressaisies après une restauration : c'est un choix de sécurité assumé, pas un oubli.
//
// ATOMICITÉ : chaque base a son propre remplacement atomique natif (une seule transaction
// IndexedDB par base, « tout ou rien » -- voir remplacerTout() dans magasin.js pour naissance-memoire
// et dans langage/connaissances.js pour naissance-langage, ajouté par ce chantier). Comme IndexedDB
// ne permet pas de transaction unique à cheval sur DEUX bases différentes, l'import complet capture
// d'abord un instantané des DEUX bases, remplace naissance-langage, puis naissance-memoire ; si le
// second remplacement échoue, naissance-langage (déjà remplacée) est restaurée à son état
// précédent -- elle aussi via un remplacement atomique. Au pire, en cas d'échec de CETTE restauration
// elle-même (double échec, non couvert par les tests), l'état pourrait rester incohérent entre les
// deux bases ; ce risque résiduel est documenté, pas caché.

import { empreinte } from './transfert.js';
import { TABLES as TABLES_LANGAGE } from '../langage/connaissances.js';

export const FORMAT_SAUVEGARDE = 'naissance-sauvegarde-complete';
// Schéma 2 (v0.62.0, ÉTAPE 6) : une sauvegarde de schéma 1 ne contient pas les tables ajoutées depuis
// ('traces' v0.46, 'actes' v0.61.4, 'enonces' v0.62.0, 'observationsComposition' v0.62.4). Avec SCHEMA_SAUVEGARDE=1 elles étaient
// REFUSÉES (« Fichier incomplet »), faute de migration ; migrerDonnees() les complète désormais par
// des tableaux vides (jamais un vécu fabriqué). Une sauvegarde de schéma 2 doit, elle, être complète.
// Schéma 3 (v0.62.4, ÉTAPE 6) : ajout de la table 'observationsComposition'. Une sauvegarde de schéma 2
// (ou 1) ne la contient pas : migrerDonnees() la complète par [] (aucune reconstruction rétroactive).
// Schéma 4 (v0.63.0, ÉTAPE 7) : ajout de la table 'observationsLangage'. Une sauvegarde de schéma 3 (ou moins)
// ne la contient pas : migrerDonnees() la complète par [] (aucune reconstruction rétroactive, jamais de
// donnée fabriquée) -- le fichier de point zéro du 04/10 (schéma 3) reste donc importable tel quel.
// Schéma 5 (v0.63.16) : ajout de la table 'observationsPossibilites'. Une sauvegarde de schéma 4 (ou moins) ne la contient pas :
// migrerDonnees() la complète par [] (aucune reconstruction rétroactive : ligne absente = calcul non effectué).
// Schéma 6 (v0.63.19) : ajout de la table 'executionsOperations'. Une sauvegarde de schéma 5 (ou moins) ne la contient pas :
// migrerDonnees() la complète par [] (aucune reconstruction rétroactive : aucune exécution n'existait avant cette version).
// Schéma 7 (v0.63.22) : ajout de la table 'designations'. Une sauvegarde de schéma 6 (ou moins) ne la contient pas :
// migrerDonnees() la complète par [] (aucune reconstruction rétroactive : aucune désignation n'existait avant cette version).
// Schéma 8 (v0.63.23) : AUCUNE nouvelle table ; les lignes de 'executionsOperations' gagnent `idDesignation`. Les lignes d'un ancien
// schéma (sans idDesignation) sont conservées EXACTEMENT telles quelles : ni réécriture, ni désignation rétroactive fabriquée.
// Schéma 9 (v0.63.27) : ajout de la table 'valeursDonnees'. Une sauvegarde de schéma 8 (ou moins) ne la contient pas : migrerDonnees() la
// complète par [] (aucune reconstruction rétroactive : les messages antérieurs à cette version ne deviennent PAS récupérables).
// Schéma 10 (v0.63.72) : ajout de la table 'contextesProspectifs'. Une sauvegarde de schéma 9 (ou moins) ne la contient pas : migrerDonnees() la
// complète par [] (aucune reconstruction rétroactive : aucun contexte prospectif n'existait avant cette version, et aucun n'est fabriqué).
// Schéma 11 (v0.63.74) : ajout de la table 'attentesProspectives'. Une sauvegarde de schéma 10 (ou moins) ne la contient pas : migrerDonnees() la
// complète par [] (aucune reconstruction rétroactive : aucune attente n'existait avant cette version, et aucune n'est fabriquée).
// Schéma 13 (v0.63.84) : ajout des tables 'capaciteInitiale' et 'variationsCapacite' (B1). Une sauvegarde de schéma 12 (ou moins) ne les contient
// pas : migrerDonnees() les complète par [] (aucune reconstruction rétroactive : l'état propre naît à la première lecture après la mise à jour).
// Schéma 14 (v0.63.86) : ajout des tables 'relationInitiale' et 'variationsRelation' (B2). Une sauvegarde de schéma 13 (ou moins) ne les contient pas :
// migrerDonnees() les complète par [] (aucune reconstruction rétroactive : l'état relationnel naît à la première lecture après la mise à jour).
// Schéma 15 (v0.64.14) : ajout de la table 'manifestationsFaits' (manifestations de faits confirmés). Une sauvegarde de schéma 14 (ou moins) ne la
// contient pas : migrerDonnees() la complète par [] (aucune reconstruction rétroactive : aucune confirmation antérieure ne devient une manifestation).
// Schéma 16 (v0.64.17) : ajout de la table 'decisionsFormes' (décisions humaines sur une forme induite). Une sauvegarde de schéma 15 (ou moins) ne
// la contient pas : migrerDonnees() la complète par [] (aucune reconstruction rétroactive : aucune règle n'avait été proposée avant cette version).
// Schéma 17 (v0.64.19) : ajout de la table 'reponsesAttendues' (réponses attendues à une question, supervisées par Christophe). Une sauvegarde de
// schéma 16 (ou moins) ne la contient pas : migrerDonnees() la complète par [] (aucune reconstruction rétroactive : aucune réponse n'avait été enseignée).
export const SCHEMA_SAUVEGARDE = 17; // MISE À JOUR DÉLIBÉRÉE v0.64.19 : 17 = 16+1 (+ reponsesAttendues) // MISE À JOUR DÉLIBÉRÉE v0.64.17 : 16 = 15+1 (+ decisionsFormes) // MISE À JOUR DÉLIBÉRÉE v0.64.14 : 15 = 14+1 (+ manifestationsFaits) // MISE À JOUR DÉLIBÉRÉE v0.63.86 (B2) : 14 = 13+1 (+ relationInitiale, variationsRelation) // MISE À JOUR DÉLIBÉRÉE v0.63.84 (B1) : 13 = 12+1 (+ capaciteInitiale, variationsCapacite) // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 12 = 11+1 (+ emissions, receptions) // MISE À JOUR DÉLIBÉRÉE v0.63.74 : 11 = 10+1 (+ attentesProspectives) // v0.63.72 : 10 = 9+1 (+ contextesProspectifs)

async function exporterTables(magasin, tables) {
  const sortie = {};
  for (const nom of tables) sortie[nom] = await magasin.lireTout(nom);
  return sortie;
}

function refus(message) {
  return { ok: false, erreur: message };
}

// Complète par des tables vides celles absentes d'une sauvegarde plus ANCIENNE que le schéma
// courant -- jamais pour le schéma courant (une table manquante y est un fichier incomplet, donc un
// refus). Ne fabrique jamais une donnée : une table absente reste vide, jamais devinée.
export function migrerDonnees(bloc, tables, schema) {
  if (schema >= SCHEMA_SAUVEGARDE) return bloc;
  const complete = { ...bloc };
  for (const nom of tables) if (!Array.isArray(complete[nom])) complete[nom] = [];
  return complete;
}

export async function construireSauvegardeComplete({ memoire, magasinLangage, idNaissance, versionAppli, maintenant }) {
  const [donneesMemoire, donneesLangage] = await Promise.all([
    memoire.exporterDonnees(),
    exporterTables(magasinLangage, TABLES_LANGAGE),
  ]);
  const donnees = { memoire: donneesMemoire, langage: donneesLangage };
  const corps = JSON.stringify(donnees);
  const exporteLe = maintenant.toISOString();
  const fichier = {
    format: FORMAT_SAUVEGARDE,
    schema: SCHEMA_SAUVEGARDE,
    exporteLe,
    versionAppli,
    idNaissance: idNaissance || null,
    empreinte: await empreinte(corps),
    donnees,
  };
  const court = (idNaissance || 'sans-id').slice(0, 8);
  return { nom: `naissance-sauvegarde-${court}-${exporteLe.slice(0, 10)}.json`, objet: fichier, contenu: JSON.stringify(fichier) };
}

export async function lireSauvegardeComplete(texte, { tablesMemoire }) {
  let f;
  try {
    f = typeof texte === 'string' ? JSON.parse(texte) : texte;
  } catch {
    return refus("Ce fichier n'est pas un fichier JSON lisible.");
  }
  if (!f || f.format !== FORMAT_SAUVEGARDE) return refus("Ce fichier n'est pas une sauvegarde complète de Naissance.");
  if (!Number.isInteger(f.schema) || f.schema < 1) return refus('Version de sauvegarde inconnue.');
  if (f.schema > SCHEMA_SAUVEGARDE) {
    return refus("Cette sauvegarde vient d'une version plus récente de Naissance : mets l'appli à jour avant de l'importer.");
  }
  const d = f.donnees;
  if (!d || typeof d !== 'object' || !d.memoire || typeof d.memoire !== 'object' || !d.langage || typeof d.langage !== 'object') {
    return refus('Fichier incomplet : données absentes.');
  }
  if (await empreinte(JSON.stringify(d)) !== f.empreinte) {
    return refus('Fichier abîmé ou modifié : son empreinte ne correspond pas.');
  }
  const memoire = migrerDonnees(d.memoire, tablesMemoire, f.schema);
  const langage = migrerDonnees(d.langage, TABLES_LANGAGE, f.schema);
  for (const nom of tablesMemoire) {
    if (!Array.isArray(memoire[nom])) return refus(`Fichier incomplet : « naissance-memoire/${nom} » manquant.`);
  }
  for (const nom of TABLES_LANGAGE) {
    if (!Array.isArray(langage[nom])) return refus(`Fichier incomplet : « naissance-langage/${nom} » manquant.`);
  }
  return {
    ok: true,
    fichier: f,
    donnees: { memoire, langage },
    resume: {
      exporteLe: f.exporteLe,
      versionAppli: f.versionAppli,
      idNaissance: f.idNaissance || null,
      schema: f.schema,
      messages: (memoire.journal || []).length,
      souvenirs: (memoire.souvenirs || []).length,
      experiences: (langage.experiences || []).length,
    },
  };
}

// IMPORT ATOMIQUE PAR BASE + FILET ENTRE LES DEUX BASES (voir commentaire d'en-tête). Remplace
// d'abord naissance-langage (remplacerTout, une seule transaction native, tout ou rien) ; si le
// remplacement de naissance-memoire échoue ENSUITE, restaure naissance-langage à son état
// précédent, capturé AVANT toute écriture, puis relance l'erreur -- jamais de silence sur l'échec.
export async function importerSauvegardeComplete({ memoire, magasinLangage, donnees }) {
  const avantLangage = await exporterTables(magasinLangage, TABLES_LANGAGE);
  const avantMemoire = await memoire.exporterDonnees();

  await magasinLangage.remplacerTout(donnees.langage);
  try {
    await memoire.remplacerDonnees(donnees.memoire, { sauvegarde: avantMemoire });
  } catch (e) {
    await magasinLangage.remplacerTout(avantLangage);
    throw e;
  }
}
// === FIN_SAUVEGARDE_COMPLETE ===
