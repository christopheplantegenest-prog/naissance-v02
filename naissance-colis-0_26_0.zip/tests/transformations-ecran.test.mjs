// Chantier « ÉDUQUER PLUTÔT QUE PROGRAMMER » (décision ChatGPT du 27/09/2026) -- ORCHESTRATION
// (langage/ecran.js) et PERSISTANCE (langage/connaissances.js). Bout en bout, sur le VRAI esprit
// partagé (chargerEsprit), comme tests/proposition-spontanee.test.mjs (v0.25) : preuves A, B, C, D
// demandées par la décision.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { magasinMemoireVive } from '../app/langage/connaissances.js';
import { monterEcranLangage } from '../app/langage/ecran.js';
import { induireTransformation } from '../app/langage/transformation.js';

const universel = () => new Proxy(function () {}, {
  get: (t, k) => (k === Symbol.toPrimitive ? () => '' : k === 'then' ? undefined : (k in t ? t[k] : universel())),
  set: () => true,
  apply: () => universel(),
});

function monter(magasin = magasinMemoireVive()) {
  const ecran = monterEcranLangage({ zone: { querySelector: () => universel() }, ouvrirStockage: async () => magasin, confirmer: () => true });
  return { magasin, ecran };
}

// ============================================================================ A. TRANSFORMATION
test('A. deux exemples cohérents (négation, banc d\'essai) → candidat induit, RIEN écrit avant confirmation', async () => {
  const { magasin } = monter();
  const r = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  assert.equal(r.ok, true);
  assert.deepEqual(await magasin.lireTout('transformations'), []);
});

test('A. un seul exemple insuffisant ne provoque pas une généralisation abusive', () => {
  const r = induireTransformation([{ entree: 'Je mange', sortie: 'Je ne mange pas' }]);
  assert.equal(r.ok, false);
  assert.equal(r.raison, 'insuffisant');
});

test('A. exemples contradictoires/ambigus → abstention', () => {
  const r = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors jamais' },
  ]);
  assert.equal(r.ok, false);
});

test('A. après confirmation explicite, application correcte à une entrée réellement nouvelle, moteur local', async () => {
  const { ecran } = monter();
  const r = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  const conf = await ecran.confirmerTransformation({ ...r.transformation, exemples: r.exemples });
  assert.match(conf.explication, /J'ai appris/);
  const application = await ecran.appliquerTransformationLocale('Je cours');
  assert.equal(application.ok, true);
  assert.equal(application.texte, 'Je ne cours pas');
});

test('A. persistance après redémarrage/rechargement (nouvel esprit sur le même magasin)', async () => {
  const magasin = magasinMemoireVive();
  const { ecran } = monter(magasin);
  const r = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  await ecran.confirmerTransformation({ ...r.transformation, exemples: r.exemples });
  const { ecran: ecranRedemarre } = monter(magasin); // même magasin, nouvel écran = équivaut à fermer/rouvrir
  const application = await ecranRedemarre.appliquerTransformationLocale('Je cours');
  assert.equal(application.ok, true);
  assert.equal(application.texte, 'Je ne cours pas');
});

test('A. aucun Gemini nécessaire : appliquerTransformationLocale ne prend aucun professeur externe', async () => {
  const { ecran } = monter();
  const r = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  await ecran.confirmerTransformation({ ...r.transformation, exemples: r.exemples });
  // monterEcranLangage ci-dessus a été monté SANS appelerGemini (null) -- la réussite de l'application
  // prouve qu'aucun accès réseau n'a été nécessaire.
  const application = await ecran.appliquerTransformationLocale('Je cours');
  assert.equal(application.texte, 'Je ne cours pas');
});

// ============================================================================ B. GÉNÉRALITÉ
test('B. le même mécanisme réussit une DEUXIÈME famille (préfixe), sans code spécifique aux deux', async () => {
  const { ecran } = monter();
  const r = induireTransformation([
    { entree: 'il chante', sortie: 'Enfin, il chante' },
    { entree: 'il arrive', sortie: 'Enfin, il arrive' },
  ]);
  assert.equal(r.ok, true);
  await ecran.confirmerTransformation({ ...r.transformation, exemples: r.exemples });
  const application = await ecran.appliquerTransformationLocale('il danse');
  assert.equal(application.ok, true);
  assert.equal(application.texte, 'Enfin, il danse');
});

// ============================================================================ C. COMPOSITION
test('C. deux transformations apprises séparément se combinent sur un cas nouveau jamais enseigné', async () => {
  const { ecran } = monter();
  const neg = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'il chante', sortie: 'il ne chante pas' },
  ]);
  const prefixe = induireTransformation([
    { entree: 'il chante', sortie: 'Enfin, il chante' },
    { entree: 'il arrive', sortie: 'Enfin, il arrive' },
  ]);
  await ecran.confirmerTransformation({ ...neg.transformation, exemples: neg.exemples });
  await ecran.confirmerTransformation({ ...prefixe.transformation, exemples: prefixe.exemples });
  // "je chante" : n'a jamais servi d'exemple ni pour neg ni pour prefixe.
  const application = await ecran.appliquerTransformationLocale('je chante');
  assert.equal(application.ok, true);
  assert.equal(application.texte, 'Enfin, je ne chante pas');
});

test('C. si plusieurs transformations de même arité se contredisent, abstention -- jamais un choix arbitraire', async () => {
  const { ecran } = monter();
  const negPas = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  await ecran.confirmerTransformation({ ...negPas.transformation, exemples: negPas.exemples });
  // Une SECONDE transformation, de même arité, apprise séparément mais contradictoire à la même
  // position (« jamais » au lieu de « pas ») -- une divergence de vécu bien réelle (deux leçons
  // données à des moments différents), pas un artefact du test.
  const negJamais = induireTransformation([
    { entree: 'Il parle', sortie: 'Il ne parle jamais' },
    { entree: 'Il rit', sortie: 'Il ne rit jamais' },
  ]);
  await ecran.confirmerTransformation({ ...negJamais.transformation, exemples: negJamais.exemples });
  const application = await ecran.appliquerTransformationLocale('Je cours');
  assert.equal(application.ok, false);
  assert.equal(application.raison, 'conflit');
});

test('C. persistance de la composition après redémarrage', async () => {
  const magasin = magasinMemoireVive();
  const { ecran } = monter(magasin);
  const neg = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'il chante', sortie: 'il ne chante pas' },
  ]);
  const prefixe = induireTransformation([
    { entree: 'il chante', sortie: 'Enfin, il chante' },
    { entree: 'il arrive', sortie: 'Enfin, il arrive' },
  ]);
  await ecran.confirmerTransformation({ ...neg.transformation, exemples: neg.exemples });
  await ecran.confirmerTransformation({ ...prefixe.transformation, exemples: prefixe.exemples });
  const { ecran: ecranRedemarre } = monter(magasin);
  const application = await ecranRedemarre.appliquerTransformationLocale('je chante');
  assert.equal(application.texte, 'Enfin, je ne chante pas');
});

// ============================================================================ Application sans transformation apprise
test('aucune transformation validée pour cette arité → abstention explicite, jamais devinée', async () => {
  const { ecran } = monter();
  const application = await ecran.appliquerTransformationLocale('Je cours');
  assert.equal(application.ok, false);
  assert.equal(application.raison, 'aucune');
});

// ============================================================================ Réapprentissage identique (pas de doublon)
test('réapprendre exactement la même transformation ajoute les exemples sans dupliquer la ligne', async () => {
  const { ecran, magasin } = monter();
  const neg1 = induireTransformation([
    { entree: 'Je mange', sortie: 'Je ne mange pas' },
    { entree: 'Je dors', sortie: 'Je ne dors pas' },
  ]);
  await ecran.confirmerTransformation({ ...neg1.transformation, exemples: neg1.exemples });
  const neg2 = induireTransformation([
    { entree: 'Je cours', sortie: 'Je ne cours pas' },
    { entree: 'Je parle', sortie: 'Je ne parle pas' },
  ]);
  await ecran.confirmerTransformation({ ...neg2.transformation, exemples: neg2.exemples });
  const toutes = await magasin.lireTout('transformations');
  assert.equal(toutes.length, 1, 'la même transformation (mêmes insertions) ne doit pas créer une seconde ligne');
  assert.equal(toutes[0].exemples.length, 4);
});
