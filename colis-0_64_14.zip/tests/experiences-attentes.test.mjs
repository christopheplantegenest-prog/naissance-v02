// v0.63.76 — experiencesDAttentes : les issues d'attentes comme collection d'expériences observables (décision ChatGPT, 08/10/2026). Preuves : vue pure sans table, composition
// seule (issueDeLAttenteProspective non réimplémentée) ; unité = une attente ayant une issue (identité idAttente) ; sans issue = hors collection, jamais un statut ; critère / avant /
// après ; regroupements A {structure, chemin} et B {+ constat attendu} (et toute autre question) ; constatsParChemin reçoit directement les éléments ; régularités de statut et
// attendu/réel par couvertures ; egale → differente ; absente (trou de couverture) ; conteneurs ordinaires ; témoins = identités ; histoire figée ; ordre non sémantique ;
// scénario réel (28) et sonde (82) ; dormance ; comportement vivant.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import * as module from '../app/langage/experiences-attentes.js';
import { experiencesDAttentes, elementsDExperiences, regrouperExperiences } from '../app/langage/experiences-attentes.js';
import { issueDeLAttenteProspective } from '../app/langage/issue-attente-prospective.js';
import { attentesDuContexteProspectif } from '../app/langage/attentes-prospectives.js';
import { contextesProspectifs } from '../app/langage/contexte-prospectif.js';
import { constatsParChemin } from '../app/langage/constats-par-chemin.js';
import { memesCouvertures } from '../app/langage/couverture-occurrences.js';
import { DESCRIPTIONS_OPERATIONS } from '../app/langage/descriptions-operations.js';
import { TABLE_OPERATIONS } from '../app/langage/table-operations.js';
import { executerApplicationsDeterminees } from '../app/langage/execution-mecanique.js';
import { executerApplicationSollicitee } from '../app/langage/execution-sollicitee.js';
import { suivreObservationDuTour } from '../app/langage/contexte-sollicitation.js';
import { traiterTourAvecEnonce } from '../app/langage/pont.js';
import { observerPossibilites } from '../app/langage/observation-possibilites.js';
import { magasinMemoireVive, enregistrerObservationPossibilites, enregistrerValeurDonnee, TABLES, VERSION_BASE } from '../app/langage/connaissances.js';
import { SCHEMA_SAUVEGARDE } from '../app/memoire/sauvegarde.js';

const RACINE = resolve(dirname(new URL(import.meta.url).pathname), '..');
const CHEMIN = join(RACINE, 'app', 'langage', 'experiences-attentes.js');
const SRC = readFileSync(CHEMIN, 'utf8');
const CODE = SRC.split('\n').filter((l) => !/^\s*\/\//.test(l)).join('\n');
const sansCommentaires = (s) => s.replace(/^\s*\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
const fichiersJs = (dir) => readdirSync(dir).flatMap((n) => { const p = join(dir, n); return statSync(p).isDirectory() ? fichiersJs(p) : /\.(m?js|html)$/.test(n) ? [p] : []; });
const refuse = (f) => assert.throws(f, (e) => e instanceof TypeError && /^experiencesDAttentes : /.test(e.message));
const sk = (st) => st.map((s) => `${s.operation}(${s.entrees.join(',')})`).join('>');
const ch = { forme: 'scalaire', genre: 'chaine' };
const coll = { forme: 'collection', elements: ch };
const DESC = [{ nom: 'eclater', entrees: { x: ch }, sortie: coll }, { nom: 'recoller', entrees: { elements: coll }, sortie: ch }];
const DESC_NC = [DESC[0], { nom: 'recoller', entrees: { elements: coll }, sortie: { forme: 'quelconque' } }];
const msg = (id, valeur) => ({ id, valeur });
const lien = (entree, donnee) => ({ entree, donnee });
let seq = 0;
const h = () => `2026-10-08T07:00:${String(++seq).padStart(2, '0')}.000Z`;
const ex = (id, operation, liaisons, resultat, idDesignation = `d-${id}`) => ({ id, horodatage: h(), idDesignation, operation, liaisons, resultat });
// Monde synthétique (celui de .75) : n expériences passées, contextes et attentes écrits « au fil de l'eau », issue courante S_{n+1} = `courante` (null : aucune).
function monde(n, { issues = [], courante, desc = DESC } = {}) {
  seq = 0;
  const M = []; const E = []; const contextes = []; const attentes = []; let numero = 0;
  let designation = null;
  for (let k = 1; k <= n + 1; k += 1) {
    M.push(msg(`m${k}`, `v${k}`));
    E.push(ex(`R${k}`, 'eclater', [lien('x', `m${k}`)], ['v', String(k)]));
    designation = { id: `d-S${k}`, horodatage: h(), idObservation: `o${k}`, operation: 'recoller', liaisons: [lien('elements', `R${k}`)] };
    const nouveaux = contextesProspectifs({ operation: 'recoller', liaisons: [lien('elements', `R${k}`)] }, M, E, desc).map((c) => ({ id: `c${k}-${c.parent ? 'p' : 'd'}`, horodatage: h(), idDesignation: `d-S${k}`, idObservation: `o${k}`, ...c }));
    contextes.push(...nouveaux);
    for (const c of nouveaux) for (const a of attentesDuContexteProspectif(c, designation, contextes, M, E, desc)) attentes.push({ id: `a${++numero}`, horodatage: h(), idObservation: `o${k}`, ...a });
    if (k <= n) E.push(ex(`S${k}`, 'recoller', [lien('elements', `R${k}`)], issues[k - 1] === undefined ? `v${k}` : issues[k - 1], `d-S${k}`));
  }
  if (courante !== null) E.push(ex(`S${n + 1}`, 'recoller', [lien('elements', `R${n + 1}`)], courante === undefined ? `v${n + 1}` : courante, `d-S${n + 1}`));
  return { M, E, contextes, attentes, desc };
}
const vue = (w) => experiencesDAttentes(w.attentes, w.contextes, w.M, w.E, w.desc);
const au = (cpc, chemin) => cpc.chemins.find((c) => memesCouvertures([c.chemin], [chemin]));
const groupe = (groupes, nomChemin, etapes = 2) => groupes.find((g) => g.cle[1].join('.') === nomChemin && g.cle[0].length === etapes); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : clé = [structure, chemin(, constat)]
const constant = (cpc, chemin) => { const c = au(cpc, chemin); return c !== undefined && c.constats.length === 1 && memesCouvertures(c.constats[0].couverture, cpc.universelle) ? c.constats[0] : null; };
const A = [['avant', 'description', 'structure'], ['avant', 'description', 'chemin']]; const B = [...A, ['avant', 'description', 'constat']]; // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : l'ancien critère { structure, chemin } est une partie de la description de l'avant
const CONSTAT = ['avant', 'description', 'constat'];

// ---------------------------------------------------------------------------------------------------------------------------------- A. CONTRAT
test('A1. exports (3 fonctions pures) ; imports exacts : issueDeLAttenteProspective + normaliserCouverture ; aucune sémantique réimplémentée ; garde anti-sémantique et anti-politique ; aucune table', () => {
  assert.deepEqual(Object.keys(module).sort(), ['elementsDExperiences', 'experiencesDAttentes', 'regrouperExperiences']);
  assert.equal(experiencesDAttentes.length, 5); assert.equal(elementsDExperiences.length, 1); assert.equal(regrouperExperiences.length, 2);
  const importees = [...SRC.matchAll(/^import .* from '(.+)';$/gm)].map((m) => m[1]).sort();
  assert.deepEqual(importees, ['./couverture-occurrences.js', './issue-attente-prospective.js', './roles-attente.js']); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.equal(/memesConstats|issueDuContexteProspectif|parcourirStructure|episodesDeTransformation|'realisee'|'autre'|'absente'|'absent'|idContexte ===|constatsParChemin\(/.test(CODE), false, 'ni ancrage, ni égalité de constats, ni statuts réimplémentés, ni statistique');
  assert.equal(/relationValeur|egale|differente|arrivee|'execution'|'vers'|symbolesDeChaine|composerCollection|'valeurs'|'depart'|applicationsSollicitables/.test(CODE), false);
  assert.equal(/reussite|réussite|echec|échec|recompense|récompense|punition|confiance|score|probab|majorit|vote|prefer|préfér|renforc|\bDate\b|Math\.random|\bawait\b|\basync\b|magasin|\.ecrire|\.lireTout|\.sort\(/i.test(CODE), false);
  assert.equal(VERSION_BASE, 25); assert.equal(SCHEMA_SAUVEGARDE, 15); assert.equal(TABLES.length, 31); // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 21 → 22 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 11 → 12 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 24 → 26 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.84 (B1, capacité d'agir) : + capaciteInitiale, variationsCapacite (VERSION_BASE 23, SCHEMA_SAUVEGARDE 13, 28 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.86 (B2, état relationnel) : + relationInitiale, variationsRelation (VERSION_BASE 24, SCHEMA_SAUVEGARDE 14, 30 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 24 → 25 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 14 → 15 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 30 → 31 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables)
});

test('A2. UNITÉ ET FORME : une expérience par attente ayant une issue, identité = id de l\'attente ; { id, idContexte, idDesignation, idExecution, avant: { description, preuve }, apres } (MISE À JOUR DÉLIBÉRÉE v0.64.7) ; rien de fusionné', () => {
  const w = monde(2);
  const { experiences, sansIssue } = vue(w);
  assert.deepEqual(sansIssue, []);
  assert.equal(experiences.length, w.attentes.length);
  assert.deepEqual(experiences.map((e) => e.id), w.attentes.map((a) => a.id), 'ordre persistant des attentes, une par attente');
  const e = experiences.find((x) => x.avant.description.chemin.join('.') === 'relationValeur' && x.idContexte === 'c3-p'); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.deepEqual(Object.keys(e), ['id', 'idContexte', 'idDesignation', 'idExecution', 'avant', 'apres']);
  assert.deepEqual(Object.keys(e.avant), ['description', 'preuve']); assert.deepEqual(Object.keys(e.avant.description), ['structure', 'chemin', 'constat']); assert.deepEqual(Object.keys(e.avant.preuve), ['temoinsContexte', 'unitesIssues']); assert.deepEqual(Object.keys(e.apres), ['statut', 'reel']);
  assert.equal(e.idExecution, 'S3'); assert.equal(e.idDesignation, 'd-S3');
  assert.deepEqual(e.avant.description.constat, { type: 'chaine', valeur: 'egale' }); assert.deepEqual(e.apres, { statut: 'realisee', reel: { type: 'chaine', valeur: 'egale' } });
  assert.deepEqual(e.avant.preuve.unitesIssues, [['c2-p', 'S2', 'relationValeur']]); // MISE À JOUR DÉLIBÉRÉE v0.63.96 (pluralité des issues) : identité d'unité uniforme [idContexte, idExecution, …chemin] (contexte × conséquence × chemin) assert.equal(e.avant.temoinsContexte.length, 2);
  // même contenu que la vue .75, réarrangé : aucune sémantique parallèle
  const ligne = w.attentes.find((a) => a.id === e.id);
  const i = issueDeLAttenteProspective(ligne, w.contextes.find((c) => c.id === e.idContexte), w.M, w.E, DESC);
  assert.deepEqual([e.avant.description, e.apres.statut, e.apres.reel], [i.description, i.statut, i.reel]); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : la description vient de l'issue, la preuve de la ligne persistée
  assert.deepEqual(e.avant.preuve, ligne.preuve);
  // deux attentes d'un même contexte / d'une même exécution restent deux expériences
  const c3 = experiences.filter((x) => x.idContexte === 'c3-p'); assert.equal(c3.length, 5); assert.equal(new Set(c3.map((x) => x.id)).size, 5); assert.equal(new Set(c3.map((x) => x.idExecution)).size, 1); // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
});

test('A3. SANS ISSUE : les attentes sans exécution ne sont pas des expériences ; leurs identifiants sont rendus à part ; aucun statut ne les représente', () => {
  const w = monde(3, { courante: null });
  const { experiences, sansIssue } = vue(w);
  const futures = w.attentes.filter((a) => a.references.idDesignation === 'd-S4').map((a) => a.id); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.deepEqual(futures, ['a12', 'a13', 'a14']); // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.deepEqual(sansIssue, futures);
  assert.equal(experiences.length, 11); assert.deepEqual([...new Set(experiences.map((e) => e.idContexte))], ['c3-d', 'c3-p'], 'seules les attentes des contextes issus (S3) sont des expériences'); // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.equal(experiences.some((e) => futures.includes(e.id)), false);
  const cpc = constatsParChemin(elementsDExperiences(experiences));
  assert.deepEqual(au(cpc, ['apres', 'statut']).constats.map((c) => c.valeur).sort(), ['autre', 'realisee']);
  assert.equal(JSON.stringify(vue(w)).includes('sansIssue":[') , true); assert.equal(/"statut":"(sans|null|aucun)/.test(JSON.stringify(vue(w))), false);
});

test('A4. REGROUPEMENTS A et B ; ATTENTE egale PUIS differente : le groupe contient les deux sortes d\'issues ; attendu constant, réel variable, statuts à couvertures distinctes ; passé intact', () => {
  const w = monde(4, { courante: 'autre' });
  const { experiences } = vue(w);
  const gA = regrouperExperiences(experiences, A); const gB = regrouperExperiences(experiences, B);
  const rel = groupe(gA, 'relationValeur');
  assert.deepEqual(rel.cle, [[{ operation: 'eclater', entrees: ['x'] }, { operation: 'recoller', entrees: ['elements'] }], ['relationValeur']]); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.equal(rel.couverture.length, 3); assert.deepEqual(rel.couverture, rel.experiences.map((e) => [e.id]).sort());
  assert.deepEqual(rel.experiences.map((e) => [e.idContexte, e.apres.statut]), [['c3-p', 'realisee'], ['c4-p', 'realisee'], ['c5-p', 'autre']]);
  const relB = groupe(gB, 'relationValeur');
  assert.deepEqual(relB.cle[2], { type: 'chaine', valeur: 'egale' }); assert.deepEqual(relB.couverture, rel.couverture, 'attendu constant : A et B coïncident ici');
  // constatsParChemin sur les éléments du groupe : seulement des constats et des couvertures
  const cpc = constatsParChemin(elementsDExperiences(rel.experiences));
  assert.deepEqual(cpc.universelle, rel.couverture);
  const statuts = au(cpc, ['apres', 'statut']).constats;
  assert.deepEqual(statuts.map((c) => [c.valeur, c.couverture.length]), [['realisee', 2], ['autre', 1]]);
  assert.deepEqual(statuts.find((c) => c.valeur === 'autre').couverture, [[rel.experiences[2].id]]);
  assert.deepEqual(constant(cpc, [...CONSTAT, 'valeur']), { type: 'chaine', valeur: 'egale', couverture: cpc.universelle }, 'attendu constant');
  assert.equal(constant(cpc, ['apres', 'reel', 'valeur']), null, 'réel variable');
  assert.deepEqual(au(cpc, ['apres', 'reel', 'valeur']).constats.map((c) => [c.valeur, c.couverture.length]), [['egale', 2], ['differente', 1]]);
  // le passé n'est ni supprimé ni réécrit : les trois premières expériences sont celles du monde d'avant la cinquième issue
  const avant = vue(monde(3)).experiences.filter((e) => e.avant.description.chemin.join('.') === 'relationValeur' && e.avant.description.structure.length === 2);
  assert.deepEqual(rel.experiences.slice(0, 2), avant);
  assert.deepEqual(w.attentes.map((a) => a.description.constat.valeur).filter((v) => v === 'egale').length, 3);
  // la structure à une étape (projection directe) forme un AUTRE groupe, non mélangé
  assert.deepEqual(groupe(gA, 'relationValeur', 1).experiences.map((e) => e.apres.statut), ['realisee', 'realisee', 'realisee']);
});

test('A5. ABSENTE : une expérience statut absente dans un groupe ; après = { statut } sans reel ; l\'absence est un trou de couverture, jamais une valeur', () => {
  const w = monde(3, { desc: DESC_NC, issues: ['x', 'x', 'x'], courante: ['pas', 'comparable'] }); // MISE À JOUR DÉLIBÉRÉE v0.63.97 (découplage des valeurs) : l'arrivée non comparable n'efface plus `valeurs` (le départ garde valeurs.depart) ; l'absence porte désormais sur valeurs.arrivee ; arrivées passées « x » pour qu'une attente valeurs.arrivee existe
  const { experiences } = vue(w);
  const val = groupe(regrouperExperiences(experiences, A), 'valeurs.arrivee');
  assert.deepEqual(val.experiences.map((e) => e.apres), [{ statut: 'realisee', reel: { type: 'chaine', valeur: 'x' } }, { statut: 'absente' }]); // MISE À JOUR DÉLIBÉRÉE v0.63.97 : groupe valeurs.arrivee (scalaire « x ») au lieu du conteneur
  const cpc = constatsParChemin(elementsDExperiences(val.experiences));
  assert.deepEqual(au(cpc, ['apres', 'statut']).constats.map((c) => [c.valeur, c.couverture.length]).sort(), [['absente', 1], ['realisee', 1]]);
  assert.equal(au(cpc, ['apres', 'reel']).couverture.length, 1); assert.equal(memesCouvertures(au(cpc, ['apres', 'reel']).couverture, cpc.universelle), false);
  assert.equal(JSON.stringify(experiences).includes('ABSENT'), false);
  assert.deepEqual(groupe(regrouperExperiences(experiences, A), 'relationValeur').experiences.at(-1).apres, { statut: 'autre', reel: { type: 'chaine', valeur: 'non_comparable' } });
});

test('A6. CONTENEURS : attendu { objet } / réel { objet } / realisee est une expérience ordinaire ; constatsParChemin la lit à [apres,reel,type] sans chemin valeur', () => {
  const { experiences } = vue(monde(4));
  const val = groupe(regrouperExperiences(experiences, B), 'valeurs', 1); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : le conteneur `valeurs` n'est plus ouvert quand le départ est connu ; il ne l'est plus que pour un départ sans valeur (contexte direct, départ collection)
  assert.deepEqual(val.cle[2], { type: 'objet' }); assert.equal(val.couverture.length, 3); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  const cpc = constatsParChemin(elementsDExperiences(val.experiences));
  assert.deepEqual(constant(cpc, ['apres', 'statut']).valeur, 'realisee');
  assert.deepEqual(constant(cpc, ['apres', 'reel', 'type']).valeur, 'objet'); assert.deepEqual(constant(cpc, [...CONSTAT, 'type']).valeur, 'objet');
  assert.equal(au(cpc, ['apres', 'reel', 'valeur']), undefined); assert.equal(au(cpc, [...CONSTAT, 'valeur']), undefined);
});

test('A7. HISTOIRE FIGÉE, ORDRE NON SÉMANTIQUE, PURETÉ : une collection plus grande ajoute sans changer les anciennes ; entrée renversée = mêmes expériences et couvertures ; entrées gelées intactes', () => {
  const w = monde(3);
  const avant = vue(w).experiences;
  const w2 = monde(6, { issues: ['v1', 'v2', 'v3', 'v4', 'autre', 'v6'] });
  const apres = vue(w2).experiences;
  assert.ok(apres.length > avant.length);
  for (const e of avant) assert.deepEqual(apres.find((x) => x.id === e.id), e);
  const renverse = experiencesDAttentes([...w2.attentes].reverse(), [...w2.contextes].reverse(), w2.M, w2.E, DESC).experiences;
  assert.deepEqual(renverse.map((e) => e.id), apres.map((e) => e.id).reverse());
  for (const e of apres) assert.deepEqual(renverse.find((x) => x.id === e.id), e);
  for (const sel of [A, B]) {
    const g1 = regrouperExperiences(apres, sel); const g2 = regrouperExperiences(renverse, sel);
    assert.equal(g1.length, g2.length);
    for (const g of g1) { const h2 = g2.find((x) => memesCouvertures(x.couverture, g.couverture)); assert.deepEqual(h2.cle, g.cle); }
  }
  const c1 = constatsParChemin(elementsDExperiences(apres)); const c2 = constatsParChemin(elementsDExperiences(renverse));
  assert.deepEqual(c1, c2, 'les régularités dépendent des couvertures, pas de la position');
  const gel = (o) => { if (o && typeof o === 'object') { Object.values(o).forEach(gel); Object.freeze(o); } return o; };
  const AT = gel(structuredClone(w.attentes)); const CT = gel(structuredClone(w.contextes)); const M = gel(structuredClone(w.M)); const E = gel(structuredClone(w.E));
  const fige = JSON.stringify([AT, CT, M, E]);
  const r1 = experiencesDAttentes(AT, CT, M, E, DESC); const r2 = experiencesDAttentes(AT, CT, M, E, DESC);
  assert.deepEqual(r1, r2); assert.notEqual(r1.experiences[0], r2.experiences[0]); assert.equal(r1.experiences[0].avant.description.constat === AT[0].description.constat, false); assert.equal(r1.experiences[0].avant.preuve === AT[0].preuve, false); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  const el = elementsDExperiences(gel(r1.experiences)); assert.equal(el[0].contenu.avant === r1.experiences[0].avant, false); assert.deepEqual(Object.keys(el[0].contenu), ['avant', 'apres']);
  regrouperExperiences(r1.experiences, B);
  assert.equal(JSON.stringify([AT, CT, M, E]), fige);
});

test('A8. entrées mal formées : TypeError, aucun résultat partiel (tableaux, contexte référencé absent, sélecteurs)', () => {
  const w = monde(2);
  refuse(() => experiencesDAttentes(null, w.contextes, w.M, w.E, DESC));
  refuse(() => experiencesDAttentes(w.attentes, {}, w.M, w.E, DESC));
  refuse(() => experiencesDAttentes(w.attentes, w.contextes.filter((c) => c.id !== 'c3-p'), w.M, w.E, DESC));
  refuse(() => experiencesDAttentes([{ ...w.attentes[0], references: { ...w.attentes[0].references, idContexte: 'x' } }], w.contextes, w.M, w.E, DESC)); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.throws(() => experiencesDAttentes([{ ...w.attentes[0], idContexte: 'c3-p' }], w.contextes, w.M, w.E, DESC), (e) => e instanceof TypeError && /^rolesDeLAttente : /.test(e.message), 'forme mêlée : refusée par la lecture des rôles');
  assert.throws(() => experiencesDAttentes([{ ...w.attentes[0], description: { ...w.attentes[0].description, chemin: ['inconnu'] } }], w.contextes, w.M, w.E, DESC), (e) => e instanceof TypeError && /^issueDeLAttenteProspective : /.test(e.message), 'les erreurs de la vue composée se propagent telles quelles');
  const { experiences } = vue(w);
  refuse(() => elementsDExperiences({}));
  refuse(() => elementsDExperiences([{ avant: {} }]));
  refuse(() => regrouperExperiences(experiences, []));
  refuse(() => regrouperExperiences(experiences, [[]]));
  refuse(() => regrouperExperiences(experiences, [['inconnu']]));
  refuse(() => regrouperExperiences(experiences, [['avant', 'inconnu']])); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
});

// ---------------------------------------------------------------------------------------------------------------------------------- B. FLUX RÉEL
let compteurIds = 0;
async function rejouer(scenario, magasin = magasinMemoireVive(), solliciter = false) {
  const nouvelId = (p) => `${p}-${++compteurIds}`;
  const tours = []; const ex2 = () => magasin.lireTout('executionsOperations');
  for (const t of scenario) {
    const suivi = suivreObservationDuTour((m) => observerPossibilites(m, { enregistrer: (d) => enregistrerObservationPossibilites(magasin, d), lireExecutions: ex2 }), (c) => executerApplicationsDeterminees(c, { magasin, table: TABLE_OPERATIONS }));
    const res = await traiterTourAvecEnonce(t, null, { enregistrerEnonce: async () => {}, traiter: async () => ({ texte: 'ok' }), nouvelId, observerPossibilites: suivi.observer, enregistrerValeur: (e) => enregistrerValeurDonnee(magasin, e) });
    const s = suivi.joindre(res).sollicitation; tours.push(s);
    if (solliciter) {
      const { observation, univers } = s; const vals = await magasin.lireTout('valeursDonnees'); const msgId = vals[vals.length - 1].id; const faits = await ex2();
      const soll = async (operation, liaisons) => { const r = await executerApplicationSollicitee({ observation, application: { operation, liaisons }, univers }, { magasin, table: TABLE_OPERATIONS }); assert.equal(r.statut, 'executee'); };
      for (const R of faits.filter((e) => e.operation === 'symbolesDeChaine')) if (!faits.some((e) => e.operation === 'composerCollection' && e.liaisons[0].donnee === R.id) && observation.donneesExaminees.includes(R.id)) await soll('composerCollection', [lien('elements', R.id)]);
      if (!(await ex2()).some((e) => e.operation === 'symbolesDeChaine' && e.liaisons[0].donnee === msgId)) await soll('symbolesDeChaine', [lien('chaine', msgId)]);
    }
  }
  const valeurs = await magasin.lireTout('valeursDonnees'); const executions = await ex2(); const contextes = await magasin.lireTout('contextesProspectifs'); const attentes = await magasin.lireTout('attentesProspectives');
  const t0 = performance.now();
  const collection = experiencesDAttentes(attentes, contextes, valeurs, executions, DESCRIPTIONS_OPERATIONS);
  return { tours, magasin, valeurs, executions, contextes, attentes, ...collection, duree: performance.now() - t0 };
}
const SCENARIO = ['bonjour Pixel', 'bonjour Luna', 'bonjour Pixel', 'bonjour Max', 'bonjour Pixel et Luna', 'au revoir Pixel', 'bonjour Luna'];
const distribution = (xs) => xs.reduce((c, e) => { c[e.apres.statut] = (c[e.apres.statut] ?? 0) + 1; return c; }, {});
const uniformes = (groupes) => groupes.filter((g) => new Set(g.experiences.map((e) => e.apres.statut)).size === 1).length;

test('B1. SCÉNARIO RÉEL (MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : le message de chaque tour est traité ; les attentes du lot reviennent, portées par des applications NOUVELLES ; .93 : 0) : toute attente devient une expérience, aucune sans issue ; groupes A = groupes B, tous uniformes en statut', async () => {
  const { tours, executions, attentes, experiences, sansIssue, duree } = await rejouer(SCENARIO);
  assert.deepEqual(tours.map((s) => s.choixAFaire.length), [0, 1, 5, 13, 13, 13, 13]);
  assert.deepEqual(tours.map((s) => s.automatiques.length), [2, 5, 10, 3, 3, 3, 3]);
  for (const s of tours) assert.deepEqual(s.dejaExecutees, [], 'aucune réexécution (.93)');
  assert.equal(executions.length, 29); assert.equal(attentes.length, 70); // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.equal(experiences.length, attentes.length); assert.deepEqual(sansIssue, []);
  const gA = regrouperExperiences(experiences, A); const gB = regrouperExperiences(experiences, B);
  assert.ok(gA.length > 0); assert.equal(gB.length, gA.length); assert.equal(uniformes(gA), gA.length); assert.equal(uniformes(gB), gB.length);
  const d = distribution(experiences); assert.ok(d.realisee > 0 && d.autre > 0, JSON.stringify(d));
  assert.ok(duree < 5000);
});

test('B1 bis. MÉCANISME (scénario dédié : univers enrichi par sollicitation extérieure — fixture —, le lot n\'exécute que des applications NOUVELLES) : toute attente devient une expérience, aucune sans issue ; groupes A = groupes B, tous uniformes en statut ; dans chaque groupe statut constant ; quand attendu et réel sont constants, réalisée ⇔ attendu = réel ; les attentes des désignations MÉCANIQUES du lot y participent', async () => {
  const { tours, attentes, experiences, sansIssue, duree } = await rejouer(SCENARIO, magasinMemoireVive(), true);
  for (const s of tours) assert.deepEqual(s.dejaExecutees, [], 'aucune réexécution : le lot n\'exécute que du nouveau');
  const duLot = new Set(tours.flatMap((s) => s.automatiques.map((r) => r.designation.id)));
  assert.ok(attentes.some((a) => duLot.has(a.references.idDesignation)), 'des attentes de désignations mécaniques NOUVELLES'); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.ok(experiences.length > 0); assert.equal(experiences.length, attentes.length); assert.deepEqual(sansIssue, []);
  const d = distribution(experiences); assert.ok(d.realisee > 0 && d.autre > 0, JSON.stringify(d));
  // MISE À JOUR DÉLIBÉRÉE v0.64.1 (attente conditionnée par la partie connue) : « un seul constat engagé par critère » est une propriété de la source
  // .74 (constat universel) ; la source conditionnée peut engager des constats différents pour un même critère selon la partie connue. Les groupes
  // A = B sont donc vérifiés sur la source .74 ; chaque expérience conditionnée est vérifiée seule (réalisée ⇔ attendu = réel).
  const conditionnees = new Set(attentes.filter((a) => Object.hasOwn(a.preuve, 'fondation')).map((a) => a.id)); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  for (const e of experiences.filter((x) => conditionnees.has(x.id))) assert.equal(e.apres.statut === 'realisee', Object.hasOwn(e.apres, 'reel') && Object.is(e.apres.reel.valeur, e.avant.description.constat.valeur) && e.apres.reel.type === e.avant.description.constat.type);
  const universelles = experiences.filter((x) => !conditionnees.has(x.id));
  const gA = regrouperExperiences(universelles, A); const gB = regrouperExperiences(universelles, B);
  assert.ok(gA.length > 0); assert.equal(gB.length, gA.length); let constants = 0; assert.equal(uniformes(gA), gA.length); assert.equal(uniformes(gB), gB.length);
  for (const g of gA) {
    const cpc = constatsParChemin(elementsDExperiences(g.experiences));
    assert.deepEqual(cpc.universelle, g.couverture);
    const statut = constant(cpc, ['apres', 'statut']); const attendu = constant(cpc, [...CONSTAT, 'valeur']); const reel = constant(cpc, ['apres', 'reel', 'valeur']);
    assert.ok(statut, 'statut constant dans chaque groupe'); if (attendu && reel) constants += 1; else continue;
    if (statut.valeur === 'realisee') assert.equal(attendu.valeur, reel.valeur); else assert.notEqual(attendu.valeur, reel.valeur);
  }
  assert.ok(constants > 0, 'des groupes à attendu et réel constants');
  const cpc = constatsParChemin(elementsDExperiences(experiences));
  assert.equal(cpc.universelle.length, experiences.length);
  assert.deepEqual(au(cpc, ['apres', 'statut']).constats.find((c) => c.valeur === 'realisee').couverture, experiences.filter((e) => e.apres.statut === 'realisee').map((e) => [e.id]).sort());
  assert.ok(duree < 5000);
});

test('B2. SONDE SIX EXPÉRIENCES : 90 expériences ; 27 groupes A = 27 B (MISE À JOUR DÉLIBÉRÉE v0.63.94 : 82 et 23 avant la causalité locale), uniformes ; groupe central relationValeur egale → egale realisee ×4, valeurs objet ×4 ; regroupement par chemin seul : identités = statut autre constant, attendu variable, réel variable', async () => {
  const { experiences, sansIssue, duree } = await rejouer(['bonjour Pixel', 'bonjour Luna', '', 'abc', 'é😀', 'éa', 'fin'], undefined, true);
  assert.equal(experiences.length, 90); assert.deepEqual(sansIssue, []); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation) // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.deepEqual(distribution(experiences), { autre: 32, realisee: 58 } /* MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : mesuré */); // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  const gA = regrouperExperiences(experiences, A); const gB = regrouperExperiences(experiences, B);
  assert.equal(gA.length, 27); assert.equal(gB.length, 27); assert.equal(uniformes(gA), 27); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation) // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  const central = gB.find((g) => sk(g.cle[0]) === 'symbolesDeChaine(chaine)>composerCollection(elements)' && g.cle[1].join('.') === 'relationValeur'); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.deepEqual(central.cle[2], { type: 'chaine', valeur: 'egale' }); assert.equal(central.couverture.length, 4);
  const cpc = constatsParChemin(elementsDExperiences(central.experiences));
  assert.equal(constant(cpc, ['apres', 'statut']).valeur, 'realisee'); assert.equal(constant(cpc, [...CONSTAT, 'valeur']).valeur, 'egale'); assert.equal(constant(cpc, ['apres', 'reel', 'valeur']).valeur, 'egale');
  assert.deepEqual(central.experiences.map((e) => `${e.avant.preuve.temoinsContexte.length}/${e.avant.preuve.unitesIssues.length}`), ['2/1', '3/2', '4/3', '5/4']);
  const objets = gB.find((g) => sk(g.cle[0]) === 'composerCollection(elements)' && g.cle[1].join('.') === 'valeurs'); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : le conteneur `valeurs` n'est plus ouvert quand le départ est connu ; il ne l'est plus que pour un départ sans valeur (contexte direct, départ collection)
  assert.deepEqual(objets.cle[2], { type: 'objet' }); assert.equal(objets.couverture.length, 4); assert.equal(constant(constatsParChemin(elementsDExperiences(objets.experiences)), ['apres', 'reel', 'type']).valeur, 'objet');
  // une autre question : même chemin, toutes structures confondues — les identités montrent statut constant / attendu variable / réel variable, sans que rien ne sache que ce sont des identités
  const gC = regrouperExperiences(experiences, [['avant', 'description', 'chemin']]); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  const arr = gC.find((g) => g.cle[0].join('.') === 'arrivee');
  assert.equal(arr.couverture.length, 10); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  const cArr = constatsParChemin(elementsDExperiences(arr.experiences));
  assert.equal(constant(cArr, ['apres', 'statut']).valeur, 'autre');
  assert.equal(constant(cArr, [...CONSTAT, 'valeur']), null); assert.equal(au(cArr, [...CONSTAT, 'valeur']).constats.length, 4); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  assert.equal(constant(cArr, ['apres', 'reel', 'valeur']), null); assert.equal(au(cArr, ['apres', 'reel', 'valeur']).constats.length, 4); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  const rel = gC.find((g) => g.cle[0].join('.') === 'relationValeur');
  const cRel = constatsParChemin(elementsDExperiences(rel.experiences));
  assert.equal(rel.couverture.length, 54); assert.equal(constant(cRel, ['apres', 'statut']).valeur, 'realisee'); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  assert.deepEqual(au(cRel, [...CONSTAT, 'valeur']).constats.map((c) => [c.valeur, c.couverture.length]).sort(), [['egale', 4], ['non_comparable', 50]] /* MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : mesuré */);
  assert.ok(duree < 10000);
});

test('B3. DORMANCE : aucun fichier de app/ n\'importe ni ne nomme la vue ; aucun mécanisme ne lit les attentes ; aucun contexte prospectif engendré sur des expériences ; catalogue et table inchangés', () => {
  for (const f of fichiersJs(join(RACINE, 'app'))) {
    if (f === CHEMIN) continue;
    assert.equal(/experiences-attentes|experiencesDAttentes|elementsDExperiences|regrouperExperiences/.test(readFileSync(f, 'utf8')), false, f);
  }
  for (const autre of ['sw.js', 'worker.js', 'index.html']) { let s = ''; try { s = readFileSync(join(RACINE, autre), 'utf8'); } catch { continue; } assert.equal(/experiences-attentes/.test(s), false, autre); }
  for (const f of fichiersJs(join(RACINE, 'app'))) if (f !== join(RACINE, 'app', 'langage', 'attentes-du-tour.js')) assert.equal(/lireTout\(\s*['"]attentesProspectives/.test(sansCommentaires(readFileSync(f, 'utf8'))), false, f); // MISE À JOUR DÉLIBÉRÉE v0.63.78 (jalon 1) : seule exception : attentes-du-tour.js (présentation, lecture seule)
  assert.equal(/contextesProspectifs|contexte-prospectif/.test(CODE), false, 'pas de méta-récursion');
  assert.equal(DESCRIPTIONS_OPERATIONS.length, 17); assert.equal(Object.keys(TABLE_OPERATIONS).length, 17);
});
