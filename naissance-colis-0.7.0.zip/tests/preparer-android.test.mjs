import { test } from 'node:test';
import assert from 'node:assert/strict';
import { preparerManifeste } from '../outils-android/preparer.mjs';

const MANIFESTE = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:label="@string/app_name"></application>
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
`;

test('micro et services vocaux ajoutés une seule fois', () => {
  const une = preparerManifeste(MANIFESTE);
  assert.equal((une.match(/RECORD_AUDIO/g) || []).length, 1);
  assert.match(une, /<queries>[\s\S]*android\.speech\.RecognitionService[\s\S]*android\.intent\.action\.TTS_SERVICE[\s\S]*<\/queries>\n<\/manifest>/);
  assert.equal(preparerManifeste(une), une, 'deuxième passage sans effet');
  assert.ok(une.includes('android.permission.INTERNET'));
});

test('manifeste inattendu : refus clair', () => {
  assert.throws(() => preparerManifeste('<pas-un-manifeste/>'), /manifest/);
});

import { preparerGradle, preparerMainActivity, VERSION_LLAMA } from '../outils-android/preparer.mjs';

const GRADLE = `apply plugin: 'com.android.application'

android {
    namespace "io.github.christopheplantegenest.naissanceia"
    defaultConfig {
        applicationId "io.github.christopheplantegenest.naissanceia"
        versionCode 7000
        versionName "0.7.0"
    }
}
`;

test('Gradle : compilation native armeabi-v7a ajoutée une seule fois, version intacte', () => {
  const g = preparerGradle(GRADLE, { ndkPath: '/sdk/ndk/27', llamaDir: '/p/app/src/main/cpp/llama.cpp' });
  assert.match(g, /ndkPath "\/sdk\/ndk\/27"/);
  assert.match(g, /path "src\/main\/cpp\/CMakeLists\.txt"/);
  assert.match(g, /abiFilters 'armeabi-v7a'/);
  assert.match(g, /-DLLAMA_DIR=\/p\/app\/src\/main\/cpp\/llama\.cpp/);
  assert.match(g, /versionCode 7000/);
  assert.equal(preparerGradle(g, { ndkPath: 'a', llamaDir: 'b' }), g);
  assert.throws(() => preparerGradle('plugins {}', { ndkPath: 'a', llamaDir: 'b' }), /inattendu/);
  assert.throws(() => preparerGradle(GRADLE, { ndkPath: '', llamaDir: 'b' }), /NDK/);
  assert.throws(() => preparerGradle(GRADLE, { ndkPath: '/a"b', llamaDir: 'b' }), /Chemin/);
  assert.equal(VERSION_LLAMA, 'b6100', 'même version que le banc d’essai validé');
});

test('MainActivity : module du moteur local enregistré avant le démarrage', () => {
  const origine = 'package io.github.christopheplantegenest.naissanceia;\n\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {}\n';
  const a = preparerMainActivity(origine);
  assert.match(a, /^package io\.github\.christopheplantegenest\.naissanceia;/);
  assert.match(a, /registerPlugin\(MoteurLocalPlugin\.class\);\n\s+super\.onCreate\(savedInstanceState\);/);
  assert.equal(preparerMainActivity(a), a);
  assert.throws(() => preparerMainActivity('public class X {}'), /inattendue/);
  assert.throws(() => preparerMainActivity('package a;\npublic class MainActivity extends BridgeActivity { public void onCreate(Bundle b) {} }'), /personnalisée/);
});
