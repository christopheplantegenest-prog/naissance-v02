// === DEBUT_LANGAGE_ECRAN ===
// L'écran du langage propre à Naissance. Isolé du reste : ni la conversation normale, ni la
// mémoire réelle, ni LFM2 ne sont touchés. Tout ce qui s'y passe vit dans la base « naissance-langage ».
//
// Il est fait pour être OBSERVABLE : à chaque réponse, elle dit ce qu'elle a compris, quel fait
// elle a retrouvé, quelle règle (le cas échéant) a servi à choisir le possessif, et quel patron
// elle a utilisé. On voit donc toujours POURQUOI elle répond ça.

import {
  chargerEsprit, repondre, apprendreFait, apprendreMot, apprendreRelation, apprendrePropriete,
  apprendreRegle, apprendreGabaritType, apprendrePatron, apprendrePatronDirect, oublierPatron, oublierFait, oublierPropriete,
  oublierRelation, oublierRegle, expliquer, COMPRIS, PARTIEL,
} from './esprit.js';
import {
  induire, repererMotifs, repartirMotifsParEtat, chronologieMotifs, motifsAvecVariationDEtat, comparerMotifs,
  formerHypothesesJugement, contientGabarit, representerExemple,
  poolExperiencesRecentes, positifsEtNegatifsDepuisMotif, candidatDepuisMotif,
} from './induction.js';
import { extraireLecon, apercuLecon, TYPES_LECON, reconstruireLeconRegle } from './lecon.js';
import { demanderEnseignement } from './gemini-professeur.js';
import {
  noterIncomprise, preparerEntreesInduction, enregistrerHypotheseSiNouvelle,
  enregistrerAttenteSiPertinente, confronterJugementEtEnregistrer,
  proposerCandidatSiNouveau, refuserProposition, confirmerPropositionApprise,
  apprendreTransformation, apprendreAction, apprendreLiaison,
} from './connaissances.js';
import { reconnaitreActions, invoquerAction, representerResultatAction } from './action.js';
import { evaluerLiaison, enregistrerResultat, invoquerAvecLiaisons } from './composition.js';
import { enregistrerTrace, enregistrerActe, enregistrerEnonceSurTrace } from './connaissances.js';
import { apresNouveauVecu as apresNouveauVecuReel } from './vecu.js';
import { possibilitesRejeuAdmissibles } from './vue-traces.js';
import { CAPACITES } from './registre.js';
import { tailleBagage, ROLES, LEXIQUE_DEPART } from './bagage.js';
import { verifierCours, donnerCours, testerCours, formaterApercu, formaterRapport } from './cours.js';
import {
  tokeniser, appliquerTransformation, fusionnerTransformations, correspondSquelette,
} from './transformation.js';
import { VERSION } from '../version.js';

export function monterEcranLangage({
  zone, ouvrirStockage, confirmer = (t) => window.confirm(t), appelerGemini = null,
  copier = (t) => navigator.clipboard.writeText(t), apresNouveauVecu = apresNouveauVecuReel,
}) {
  const $ = (s) => zone.querySelector(s);
  const fil = $('[data-langage-fil]');
  const formulaire = $('[data-langage-formulaire]');
  const champ = $('[data-langage-question]');
  const etat = $('[data-langage-etat]');
  const bSavoir = $('[data-langage-savoir]');
  const bGererTout = $('[data-langage-gerer-tout]');
  const zoneListeTout = $('[data-langage-liste-tout]');
  const bJournal = $('[data-langage-journal]');
  const bOublier = $('[data-langage-oublier]');
  const formFait = $('[data-langage-form-fait]');
  const formMot = $('[data-langage-form-mot]');
  const formRelation = $('[data-langage-form-relation]');
  const formPropriete = $('[data-langage-form-propriete]');
  const formRegle = $('[data-langage-form-regle]');
  const formLecon = $('[data-langage-form-lecon]');
  const zoneConfirmation = $('[data-langage-confirmation]');
  const texteConfirmation = $('[data-langage-confirmation-texte]');
  const bConfirmer = $('[data-langage-confirmer]');
  const bAnnuler = $('[data-langage-annuler]');
  const formPatron = $('[data-langage-form-patron]');
  const formEnseignement = $('[data-langage-form-enseignement]');
  const etatGemini = $('[data-langage-gemini-etat]');
  const zoneNote = $('[data-langage-gemini-note]');
  const texteNote = $('[data-langage-gemini-note-texte]');
  const zoneRejetees = $('[data-langage-gemini-rejetees]');
  const listeRejetees = $('[data-langage-gemini-rejetees-liste]');
  const zoneCandidats = $('[data-langage-gemini-candidats]');
  const bTestPrerequis = $('[data-langage-test-prerequis]');
  const bTestSujet = $('[data-langage-test-sujet]');
  const bTestQuestion = $('[data-langage-test-question]');
  const bTestXyzz = $('[data-langage-test-xyzz]');
  const bTestGrbl = $('[data-langage-test-grbl]');
  const bTestSequence = $('[data-langage-test-sequence]');
  const etatTest = $('[data-langage-test-etat]');
  const champCours = $('[data-langage-cours-texte]');
  const bCoursVerifier = $('[data-langage-cours-verifier]');
  const bCoursConfirmer = $('[data-langage-cours-confirmer]');
  const bCoursTester = $('[data-langage-cours-tester]');
  const bCoursCopier = $('[data-langage-cours-copier]');
  const etatCours = $('[data-langage-cours-etat]');
  const apercuCours = $('[data-langage-cours-apercu]');
  const rapportCours = $('[data-langage-cours-rapport]');
  const champInductionPositifs = $('[data-langage-induction-positifs]');
  const champInductionNegatifs = $('[data-langage-induction-negatifs]');
  const champInductionSignification = $('[data-langage-induction-signification]');
  const bInductionLancer = $('[data-langage-induction-lancer]');
  const bInductionConfirmer = $('[data-langage-induction-confirmer]');
  const bInductionAnnuler = $('[data-langage-induction-annuler]');
  const etatInduction = $('[data-langage-induction-etat]');
  const rapportInduction = $('[data-langage-induction-rapport]');
  const champInductionTestTexte = $('[data-langage-induction-test-texte]');
  const bInductionTestLancer = $('[data-langage-induction-test-lancer]');
  const resultatInductionTest = $('[data-langage-induction-test-resultat]');
  const bExperiencesLister = $('[data-langage-experiences-lister]');
  const etatExperiences = $('[data-langage-experiences-etat]');
  const rapportExperiences = $('[data-langage-experiences-rapport]');
  const champSelectionPositifs = $('[data-langage-selection-positifs]');
  const champSelectionNegatifs = $('[data-langage-selection-negatifs]');
  const bSelectionEnvoyer = $('[data-langage-selection-envoyer]');
  const etatSelection = $('[data-langage-selection-etat]');

  let magasin = null;
  let esprit = null;
  let leconEnAttente = null;

  async function assurer() {
    if (!esprit) {
      magasin = await ouvrirStockage();
      esprit = await chargerEsprit(magasin);
    }
    return esprit;
  }

  function ajouter(qui, texte, details = null) {
    const bloc = document.createElement('div');
    bloc.className = qui === 'moi' ? 'message message-moi' : 'message message-ia';
    const p = document.createElement('p');
    p.textContent = texte;
    bloc.appendChild(p);
    if (details) {
      const d = document.createElement('p');
      d.className = 'aide';
      d.textContent = details;
      bloc.appendChild(d);
    }
    fil.appendChild(bloc);
    fil.scrollTop = fil.scrollHeight;
  }

  async function dessiner() {
    const e = await assurer();
    const depart = tailleBagage();
    const reglesActives = e.regles.filter((r) => r.statut === 'validee').length;
    // v0.17.1 — compteur de faits = nombre de LIGNES réellement en jeu (diagnosticFaits.lignes),
    // pas le nombre d'identités : une identité en conflit correspond à plusieurs lignes.
    etat.textContent = `Elle connaît ${Object.keys(e.lexique).length} mots (${depart.mots} au départ), `
      + `${e.diagnosticFaits.lignes} faits (${depart.faits} au départ), `
      + `${e.patrons.length} façons de dire (${depart.patrons} au départ), `
      + `${[...e.proprietes.values()].reduce((n, m) => n + m.size, 0)} propriétés, `
      + `${reglesActives} règles actives.`
      + (e.diagnosticFaits.conflits ? ` ${e.diagnosticFaits.conflits} conflit${e.diagnosticFaits.conflits > 1 ? 's' : ''} de faits.` : '')
      + (e.diagnosticFaits.ancienneGraphie ? ` ${e.diagnosticFaits.ancienneGraphie} fait${e.diagnosticFaits.ancienneGraphie > 1 ? 's' : ''} enregistré${e.diagnosticFaits.ancienneGraphie > 1 ? 's' : ''} sous une ancienne graphie.` : '')
      // v0.46 — compteur PUREMENT INFORMATIF (observation passive des tentatives de raisonnement) :
      // même principe que les compteurs ci-dessus (lecture seule de e.traces, aucune interprétation,
      // aucun comportement n'en dépend) — permet de vérifier concrètement, à l'écran, qu'une trace est
      // bien conservée après chaque invocation réelle d'une capacité.
      + ` ${e.traces.length} trace${e.traces.length > 1 ? 's' : ''} de raisonnement enregistrée${e.traces.length > 1 ? 's' : ''}.`;
  }

  formulaire.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const question = champ.value.trim();
    if (!question) return;
    champ.value = '';
    ajouter('moi', question);
    // Une question ne doit JAMAIS échouer en silence : si quelque chose se passe mal, on le montre,
    // au lieu de laisser l'écran sans réponse sans que Christophe sache pourquoi.
    try {
      const e = await assurer();
      const r = repondre(e, question);
      const details = [
        expliquer(r.comprehension),
        r.fait ? `Fait retrouvé : ${r.fait.sujet} → ${r.fait.relation} → ${r.fait.valeur}.` : null,
        r.regleUtilisee ? `Règle utilisée pour le possessif : ${r.regleUtilisee.conditions.map((c) => `${c.propriete}=${c.valeur}`).join(', ')} → ${r.regleUtilisee.resultat}.` : null,
        r.patron ? `Façon de dire : ${r.patron.origine === 'appris' ? 'apprise' : 'de départ'} (${r.patron.gabarit}).` : null,
      ].filter(Boolean).join(' ');
      ajouter('ia', r.texte, details);
      let etatJournal = null;
      if (r.conflit) etatJournal = 'conflit';
      else if (r.conflitPatron) etatJournal = 'conflit-patron';
      else if (r.regleManquante) etatJournal = 'regle-manquante';
      else if (r.etat !== COMPRIS || !r.fait) etatJournal = r.etat === COMPRIS ? 'fait-manquant' : r.etat;
      if (etatJournal) {
        await noterIncomprise(magasin, {
          phrase: question, etat: etatJournal,
          sujet: r.comprehension.sujet, relation: r.comprehension.relation,
          motsInconnus: r.comprehension.motsInconnus,
        });
      }
    } catch (err) {
      ajouter('ia', `(Un problème technique m'a empêchée de répondre : ${err.message})`);
    }
    await dessiner();
  });

  formFait.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formFait);
    const e = await assurer();
    try {
      const r = await apprendreFait(e, {
        sujet: String(d.get('sujet')).trim(), relation: String(d.get('relation')).trim().toLowerCase(), valeur: String(d.get('valeur')).trim(),
      });
      ajouter('ia', r.explication);
      formFait.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  formMot.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formMot);
    const e = await assurer();
    try {
      const r = await apprendreMot(e, { motNouveau: String(d.get('nouveau')), motConnu: String(d.get('connu')) });
      ajouter('ia', r.explication);
      formMot.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  formRelation.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formRelation);
    const e = await assurer();
    try {
      const r = await apprendreRelation(e, { mot: String(d.get('mot')), relation: String(d.get('relation')) });
      ajouter('ia', r.explication);
      formRelation.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  formPropriete.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formPropriete);
    const e = await assurer();
    try {
      const r = await apprendrePropriete(e, { mot: String(d.get('mot')), propriete: String(d.get('propriete')), valeur: String(d.get('valeur')) });
      ajouter('ia', r.explication);
      formPropriete.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  formRegle.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formRegle);
    const e = await assurer();
    try {
      const r = await apprendreRegle(e, {
        role: String(d.get('role')).trim(),
        conditions: [{ propriete: String(d.get('propriete')).trim(), valeur: String(d.get('valeurPropriete')).trim() }],
        resultat: String(d.get('resultat')).trim(),
        exemple: String(d.get('exemple') || '').trim() || null,
      });
      ajouter('ia', r.explication);
      formRegle.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  // Le canal pédagogique (v0.11, généralisé en v0.12 à quatre types) : une phrase à forme fixe,
  // jamais devinée si elle ne la respecte pas. Rien n'est enregistré avant confirmation explicite —
  // c'est ce qui permet de voir une mauvaise interprétation AVANT qu'elle n'entre en mémoire.
  formLecon.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formLecon);
    const texteLecon = String(d.get('lecon')).trim();
    formLecon.reset();
    const extrait = extraireLecon(texteLecon);
    if (!extrait) {
      const formes = Object.values(TYPES_LECON).map((f) => `\n• ${f}`).join('');
      ajouter('ia', `Je ne reconnais pas cette forme de leçon. Les formes que je comprends sont :${formes}`);
      return;
    }
    leconEnAttente = { ...extrait, texteLecon };
    texteConfirmation.textContent = apercuLecon(extrait);
    zoneConfirmation.hidden = false;
  });

  // Dispatch vers le mécanisme d'apprentissage EXISTANT correspondant au type reconnu — aucune de
  // ces quatre fonctions n'est réécrite pour le canal pédagogique, seul l'aiguillage est nouveau.
  // Partagé entre une leçon tapée par Christophe et une leçon proposée par Gemini (v0.13) : le
  // chemin d'écriture est rigoureusement le même, seule l'origine tracée diffère.
  async function ecrireConnaissance(e, { type, donnees }, { origine, exemple } = {}) {
    if (type === 'relation') return apprendreRelation(e, { ...donnees, origine: origine || 'apprise-christophe' });
    if (type === 'fait') return apprendreFait(e, { ...donnees, origine: origine || 'apprise-christophe' });
    if (type === 'propriete') return apprendrePropriete(e, { ...donnees, origine: origine || 'apprise-christophe' });
    if (type === 'regle') return apprendreRegle(e, { ...donnees, origine: origine || 'apprise-christophe', exemple: exemple || null });
    if (type === 'patron') return apprendrePatronDirect(e, donnees);
    throw new Error('Type de leçon inconnu.');
  }

  bConfirmer.addEventListener('click', async () => {
    if (!leconEnAttente) return;
    const { type, donnees, texteLecon } = leconEnAttente;
    const e = await assurer();
    try {
      const r = await ecrireConnaissance(e, { type, donnees }, { origine: 'apprise-lecon', exemple: texteLecon });
      ajouter('ia', r.explication);
    } catch (err) { ajouter('ia', err.message); }
    leconEnAttente = null;
    zoneConfirmation.hidden = true;
    await dessiner();
  });

  bAnnuler.addEventListener('click', () => {
    leconEnAttente = null;
    zoneConfirmation.hidden = true;
    ajouter('ia', "D'accord, je n'ai rien retenu de cette leçon.");
  });

  // --- Gemini comme professeur ponctuel (v0.13) ---------------------------------------------------
  // Gemini n'est jamais considéré comme fiable par défaut : chaque ligne reçue repasse par le même
  // extraireLecon() qu'une leçon tapée à la main (voir demanderEnseignement, gemini-professeur.js).
  // Plusieurs propositions peuvent arriver à la fois ; chacune reste confirmée ou rejetée
  // individuellement, jamais en bloc.
  function afficherCandidatGemini({ texte, extrait }) {
    const bloc = document.createElement('div');
    bloc.className = 'candidat-gemini';
    const p = document.createElement('p');
    p.className = 'aide';
    p.textContent = apercuLecon(extrait);
    bloc.appendChild(p);
    const ligne = document.createElement('div');
    ligne.className = 'ligne';
    const bOk = document.createElement('button');
    bOk.type = 'button'; bOk.className = 'bouton-principal'; bOk.textContent = 'Confirmer';
    const bNon = document.createElement('button');
    bNon.type = 'button'; bNon.className = 'bouton-secondaire'; bNon.textContent = 'Rejeter';
    ligne.appendChild(bOk); ligne.appendChild(bNon);
    bloc.appendChild(ligne);
    bOk.addEventListener('click', async () => {
      const e = await assurer();
      try {
        const r = await ecrireConnaissance(e, extrait, { origine: 'apprise-gemini', exemple: texte });
        ajouter('ia', r.explication);
      } catch (err) { ajouter('ia', err.message); }
      bloc.remove();
      await dessiner();
    });
    bNon.addEventListener('click', () => bloc.remove());
    zoneCandidats.appendChild(bloc);
  }

  if (formEnseignement) {
    formEnseignement.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const sujet = String(new FormData(formEnseignement).get('sujet')).trim();
      if (!sujet) return;
      zoneNote.hidden = true;
      zoneRejetees.hidden = true;
      zoneCandidats.textContent = '';
      etatGemini.textContent = 'Je demande à Gemini…';
      try {
        if (!appelerGemini) throw new Error("Aucun professeur externe n'est disponible ici.");
        const e = await assurer();
        // Un exemple de ce que Naissance sait déjà, dans son propre format — pour ancrer le
        // vocabulaire de Gemini (même rôle, même propriété) sans jamais lui faire confiance pour
        // autant : la vérification par extraireLecon() reste la même, avec ou sans exemple.
        const exemplesConnus = e.regles
          .filter((r) => r.statut === 'validee' && r.role === 'possessif_toi')
          .map((r) => reconstruireLeconRegle(r));
        const { note, reconnues, rejetees } = await demanderEnseignement({ sujet, exemplesConnus, appelerGemini });
        etatGemini.textContent = reconnues.length || rejetees.length
          ? `Gemini a proposé ${reconnues.length + rejetees.length} ligne(s) : ${reconnues.length} reconnue(s), ${rejetees.length} refusée(s).`
          : 'Gemini n’a proposé aucune leçon exploitable cette fois.';
        if (note) { texteNote.textContent = note; zoneNote.hidden = false; }
        if (rejetees.length) {
          listeRejetees.textContent = '';
          for (const r of rejetees) {
            const li = document.createElement('li');
            li.textContent = r;
            listeRejetees.appendChild(li);
          }
          zoneRejetees.hidden = false;
        }
        for (const candidat of reconnues) afficherCandidatGemini(candidat);
      } catch (err) {
        etatGemini.textContent = `Je n'ai pas pu obtenir d'enseignement : ${err.message}`;
      }
    });
  }

  // --- Protocole de test rapide (v0.13) : réduit la recopie, jamais l'écriture réelle -------------
  // Chaque bouton PRÉREMPLIT ou exécute un geste normal — rien n'est simulé, rien n'est caché.
  if (bTestPrerequis) {
    bTestPrerequis.addEventListener('click', async () => {
      const e = await assurer();
      const faits = [];
      try {
        await apprendreRelation(e, { mot: 'stylo', relation: 'stylo' }); faits.push('relation « stylo »');
        await apprendreFait(e, { sujet: 'moi', relation: 'stylo', valeur: 'un Bic' }); faits.push('fait moi/stylo/un Bic');
        await apprendrePropriete(e, { mot: 'stylo', propriete: 'genre', valeur: 'masculin' }); faits.push('propriété stylo/genre/masculin');
        await apprendrePatron(e, { correction: 'Ta stylo, c’est un Bic.', sujet: 'moi', relation: 'stylo', portee: 'toutes', dynamiserPossessif: true });
        faits.push('façon de dire générale (possessif calculé)');
        etatTest.textContent = `Prérequis prêts : ${faits.join(', ')}.`;
      } catch (err) {
        etatTest.textContent = `Interrompu après « ${faits.join(', ') || 'rien'} » : ${err.message}`;
      }
      await dessiner();
    });
  }
  if (bTestSujet) {
    bTestSujet.addEventListener('click', () => {
      const champSujet = zone.querySelector('[data-langage-form-enseignement] [name=sujet]');
      if (champSujet) champSujet.value = 'le possessif masculin : comment dit-on « ton » plutôt que « ta » devant un nom masculin en français ?';
      etatTest.textContent = 'Sujet prérempli : ouvre « Demander un enseignement à Gemini » ci-dessus et appuie sur Demander.';
    });
  }
  if (bTestQuestion) {
    bTestQuestion.addEventListener('click', () => {
      champ.value = 'Quel est mon stylo ?';
      etatTest.textContent = 'Question préremplie tout en haut : appuie sur Demander.';
    });
  }

  // Chantier 2 (v0.14.1) : préparer un rôle jamais codé en JavaScript, de bout en bout, par les
  // vrais mécanismes (relation, fait, propriété, règle, patron) — un seul tap, une vraie écriture.
  // Patron délibérément SPÉCIFIQUE (portee: 'relation', pas 'toutes') : une façon de dire générale
  // existe déjà en mémoire depuis les chantiers précédents, et la rendre générale aussi créerait
  // un conflit qui n'aurait rien à voir avec ce qu'on teste ici.
  async function preparerTestRole({ role, resultat, mot, valeurFait, propriete, valeurPropriete }) {
    const e = await assurer();
    const etapes = [];
    try {
      await apprendreRelation(e, { mot, relation: mot }); etapes.push(`relation « ${mot} »`);
      await apprendreFait(e, { sujet: 'moi', relation: mot, valeur: valeurFait }); etapes.push('fait');
      await apprendrePropriete(e, { mot, propriete, valeur: valeurPropriete }); etapes.push('propriété');
      await apprendreRegle(e, { role, conditions: [{ propriete, valeur: valeurPropriete }], resultat }); etapes.push(`règle « ${role} »`);
      await apprendrePatron(e, { correction: `{${role}} ${mot}, c’est ${valeurFait}.`, sujet: 'moi', relation: mot });
      etapes.push('façon de dire (spécifique à ce mot)');
      etatTest.textContent = `Prêt : ${etapes.join(', ')}. Demande maintenant « Quel est mon ${mot} ? » — attendu : « ${resultat} ${mot}, c’est ${valeurFait}. »`;
    } catch (err) {
      etatTest.textContent = `Interrompu après « ${etapes.join(', ') || 'rien'} » : ${err.message}`;
    }
    await dessiner();
  }
  if (bTestXyzz) {
    bTestXyzz.addEventListener('click', () => preparerTestRole({
      role: 'xyzz', resultat: 'QUD', mot: 'gadget', valeurFait: 'un widget', propriete: 'attribut', valeurPropriete: 'zorx',
    }));
  }
  if (bTestGrbl) {
    bTestGrbl.addEventListener('click', () => preparerTestRole({
      role: 'grbl', resultat: 'PLOP', mot: 'artefact', valeurFait: 'un item', propriete: 'marque', valeurPropriete: 'bar',
    }));
  }

  // Chantier « patrons pédagogiques » (v0.14.2) : contrairement aux préréglages ci-dessus, celui-ci
  // ne PRÉPARE rien directement — il préremplit le champ « Une leçon » avec la phrase suivante d'une
  // séquence, mais chaque écriture (y compris la façon de dire) doit encore passer par le vrai
  // canal : Proposer, puis Confirmer. C'est précisément ce que ce test démontre, donc rien ne doit
  // le contourner. Aucun bouton d'installation manuelle du patron n'existe ici, volontairement.
  const SEQUENCE_TEST_PATRON = [
    'Mot : gadget désigne gadget.',
    'Fait : moi / gadget / un widget.',
    'Propriété : gadget / attribut / zorx.',
    'Pour blurf : si attribut vaut zorx, on dit ZAP.',
    'Façon de dire : gadget / moi / {blurf} gadget, c’est {valeur}.',
    'Mot : chose désigne chose.',
    'Fait : moi / chose / un item.',
    'Propriété : chose / truc / bar.',
    'Pour nork : si truc vaut bar, on dit YOP.',
    'Façon de dire : chose / moi / {nork} chose, c’est {valeur}.',
  ];
  let indexSequenceTest = 0;
  if (bTestSequence) {
    bTestSequence.addEventListener('click', () => {
      const champLecon = zone.querySelector('[data-langage-form-lecon] [name=lecon]');
      if (indexSequenceTest >= SEQUENCE_TEST_PATRON.length) {
        etatTest.textContent = 'Séquence terminée : demande « Quel est mon gadget ? » puis « Quelle est ma chose ? » tout en haut.';
        indexSequenceTest = 0;
        return;
      }
      if (champLecon) champLecon.value = SEQUENCE_TEST_PATRON[indexSequenceTest];
      etatTest.textContent = `Leçon ${indexSequenceTest + 1}/${SEQUENCE_TEST_PATRON.length} prête dans « Une leçon » ci-dessus : appuie sur « Proposer cette leçon », puis « Confirmer ». Reviens ici ensuite pour la suivante.`;
      indexSequenceTest++;
    });
  }

  formPatron.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = new FormData(formPatron);
    const e = await assurer();
    try {
      const r = await apprendrePatron(e, {
        correction: String(d.get('correction')), sujet: String(d.get('sujet')).trim(),
        relation: String(d.get('relation')).trim().toLowerCase(),
        portee: d.get('portee') === 'toutes' ? 'toutes' : 'relation',
        dynamiserPossessif: d.get('possessif') === 'oui',
      });
      ajouter('ia', r.explication);
      formPatron.reset();
    } catch (err) { ajouter('ia', err.message); }
    await dessiner();
  });

  bSavoir.addEventListener('click', async () => {
    const e = await assurer();
    const lignes = ['— Ce que je sais —'];
    for (const f of e.faits.values()) lignes.push(`${f.sujet} → ${f.relation} → ${f.valeur}`);
    for (const candidats of e.conflitsFaits.values()) {
      lignes.push(`${candidats[0].sujet} → ${candidats[0].relation} → [CONFLIT : ${candidats.map((c) => c.valeur).join(' / ')}]`);
    }
    lignes.push('— Mes propriétés —');
    for (const [mot, props] of e.proprietes) for (const [p, v] of props) lignes.push(`${mot} → ${p} → ${v}`);
    lignes.push('— Mes règles —');
    for (const r of e.regles) {
      lignes.push(`[${r.statut}] ${r.role} : ${r.conditions.map((c) => `${c.propriete}=${c.valeur}`).join(', ')} → ${r.resultat}`
        + ` (${r.origine})${r.precedente ? ' — remplace une règle précédente' : ''}`);
    }
    lignes.push('— Mes façons de dire —');
    for (const p of e.patrons) lignes.push(`${p.relation === '*' ? 'toutes' : p.relation} : ${p.gabarit}${p.origine === 'appris' ? ' (appris)' : ''}`);
    ajouter('ia', lignes.join('\n'));
  });

  // Les façons de dire n'ont pas de mécanisme de version (contrairement aux règles) : en réapprendre
  // une n'efface jamais l'ancienne, ce qui peut en laisser deux générales se contredire. Ce panneau
  // permet de retirer UNE SEULE façon de dire précise, sans toucher au reste — l'alternative,
  // « Tout lui faire oublier », efface tout, ce qui est disproportionné pour ce cas.
  // Panneau unique « Gérer ce qu'elle sait » (v0.14) : les cinq types de connaissances à la suite,
  // chacun avec un retrait ciblé quand c'est possible. Le bagage de départ n'a jamais de bouton :
  // il n'existe pas en base, le « retirer » n'y survivrait pas à un redémarrage.
  function ligneGestion(texte, onRetrait) {
    const bloc = document.createElement('div');
    bloc.className = 'ligne-patron';
    const p = document.createElement('p');
    p.className = 'aide';
    p.textContent = texte;
    bloc.appendChild(p);
    if (onRetrait) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'bouton-secondaire';
      b.textContent = 'Oublier';
      b.addEventListener('click', onRetrait);
      bloc.appendChild(b);
    }
    zoneListeTout.appendChild(bloc);
  }
  function titreGestion(texte) {
    const p = document.createElement('p');
    p.className = 'aide';
    const strong = document.createElement('strong');
    strong.textContent = texte;
    p.appendChild(strong);
    zoneListeTout.appendChild(p);
  }

  bGererTout.addEventListener('click', async () => {
    const e = await assurer();
    zoneListeTout.textContent = '';

    titreGestion('Mots qu\'elle connaît (informations et synonymes)');
    for (const [mot, entree] of Object.entries(e.lexique)) {
      if (entree.role !== ROLES.RELATION) continue;
      const appris = !LEXIQUE_DEPART[mot];
      ligneGestion(`${mot} → ${entree.relation}${appris ? ' (apprise)' : ' (de départ)'}`, appris ? async () => {
        if (!confirmer(`Oublier que « ${mot} » désigne une information ? Les faits et propriétés déjà donnés à son sujet resteront en mémoire, réutilisables si tu réenseignes ce mot.`)) return;
        try { const r = await oublierRelation(e, mot); ajouter('ia', r.explication); } catch (err) { ajouter('ia', err.message); }
        bGererTout.click();
        await dessiner();
      } : null);
    }

    titreGestion('Faits');
    for (const f of e.faits.values()) {
      ligneGestion(`${f.sujet} → ${f.relation} → ${f.valeur}`, async () => {
        if (!confirmer(`Oublier ce fait : ${f.sujet} → ${f.relation} → ${f.valeur} ?`)) return;
        try { const r = await oublierFait(e, { sujet: f.sujet, relation: f.relation }); ajouter('ia', r.explication); } catch (err) { ajouter('ia', err.message); }
        bGererTout.click();
        await dessiner();
      });
    }
    // v0.17.1 — un conflit vient de PLUSIEURS lignes réellement stockées pour la même identité
    // (héritées d'avant cette version). Chacune reste visible, avec son propre Oublier ciblé par sa
    // clé de ligne : jamais de choix automatique entre elles.
    for (const [, candidats] of e.conflitsFaits) {
      for (const ligne of candidats) {
        ligneGestion(`[CONFLIT] ${ligne.sujet} → ${ligne.relation} → ${ligne.valeur}`, async () => {
          if (!confirmer(`Oublier cette ligne en conflit : ${ligne.sujet} → ${ligne.relation} → ${ligne.valeur} ?`)) return;
          try {
            const r = await oublierFait(e, { sujet: ligne.sujet, relation: ligne.relation, cle: ligne.cle });
            ajouter('ia', r.explication);
          } catch (err) { ajouter('ia', err.message); }
          bGererTout.click();
          await dessiner();
        });
      }
    }

    titreGestion('Propriétés');
    for (const [mot, props] of e.proprietes) {
      for (const [prop, valeur] of props) {
        ligneGestion(`${mot} → ${prop} → ${valeur}`, async () => {
          if (!confirmer(`Oublier cette propriété : ${mot} → ${prop} → ${valeur} ?`)) return;
          try { const r = await oublierPropriete(e, { mot, propriete: prop }); ajouter('ia', r.explication); } catch (err) { ajouter('ia', err.message); }
          bGererTout.click();
          await dessiner();
        });
      }
    }

    titreGestion('Règles');
    for (const r of e.regles) {
      const texte = `[${r.statut}] ${r.role} : ${r.conditions.map((c) => `${c.propriete}=${c.valeur}`).join(', ')} → ${r.resultat} (${r.origine})`;
      ligneGestion(texte, r.statut === 'validee' ? async () => {
        if (!confirmer(`Désactiver cette règle : ${r.role} → ${r.resultat} ? Son historique reste consultable, elle ne sera simplement plus utilisée.`)) return;
        try { const res = await oublierRegle(e, r.id); ajouter('ia', res.explication); } catch (err) { ajouter('ia', err.message); }
        bGererTout.click();
        await dessiner();
      } : null);
    }

    titreGestion('Façons de dire');
    for (const patron of e.patrons) {
      const appris = patron.origine === 'appris';
      ligneGestion(`${patron.relation === '*' ? 'toutes les informations' : patron.relation} : ${patron.gabarit}${appris ? ' (apprise)' : ' (de départ)'}`, appris ? async () => {
        if (!confirmer(`Oublier cette façon de dire : « ${patron.gabarit} » ?`)) return;
        try { const r = await oublierPatron(e, patron.id); ajouter('ia', r.explication); } catch (err) { ajouter('ia', err.message); }
        bGererTout.click();
        await dessiner();
      } : null);
    }
  });

  bJournal.addEventListener('click', async () => {
    await assurer();
    const entrees = await magasin.lireTout('journal');
    if (!entrees.length) { ajouter('ia', 'Rien : j’ai compris tout ce que tu m’as dit jusqu’ici.'); return; }
    const lignes = ['— Ce que je n’ai pas su traiter —'];
    const CAUSES = {
      'fait-manquant': 'comprise, mais je ne sais pas la réponse',
      [PARTIEL]: 'comprise à moitié',
      'regle-manquante': 'comprise, mais je ne sais pas comment le dire',
      conflit: 'comprise, mais deux règles se contredisent',
      'conflit-patron': 'comprise, mais deux façons de dire se contredisent',
    };
    for (const e of entrees.sort((a, b) => b.fois - a.fois)) {
      const cause = CAUSES[e.etat] || 'pas comprise';
      lignes.push(`« ${e.phrase} » — ${cause} (${e.fois} fois)${e.motsInconnus.length ? ` — mots inconnus : ${e.motsInconnus.join(', ')}` : ''}`);
    }
    ajouter('ia', lignes.join('\n'));
  });

  bOublier.addEventListener('click', async () => {
    if (!confirmer('Tout effacer de ce qu’elle a appris ici ? Sa mémoire réelle et sa conversation ne changent pas.')) return;
    await assurer();
    await magasin.vider();
    esprit = await chargerEsprit(magasin);
    ajouter('ia', 'J’ai tout oublié de ce que tu m’as appris ici. Je repars avec mon bagage de départ.');
    await dessiner();
  });

  // --- v0.17 : « Donner un cours » ------------------------------------------------------------------------
  // Une leçon groupée collée depuis ChatGPT / Claude (format et logique : cours.js, module pur). Ici, seulement
  // le câblage : Vérifier (aucune écriture) → Confirmer la leçon (UNE confirmation) ; « Tester seulement »
  // n'écrit rien. Le Décor n'est jamais écrit dans la vraie base. Les exercices passent par repondre().
  let coursVerifie = null;
  let dernierRapport = '';
  const boutonsCours = [bCoursVerifier, bCoursConfirmer, bCoursTester];

  function afficherRapport(res) {
    dernierRapport = formaterRapport(res, { version: VERSION });
    rapportCours.textContent = dernierRapport;
    rapportCours.hidden = false;
    bCoursCopier.disabled = false;
  }
  async function contexteCours() {
    const e = await assurer();
    return { magasin, esprit: e, ecrire: ecrireConnaissance };
  }
  async function executerCours(action) {
    boutonsCours.forEach((b) => { b.disabled = true; });
    try { await action(); } catch (err) {
      etatCours.textContent = `Un problème technique m'a arrêtée : ${err && err.message ? err.message : err}`;
    } finally {
      bCoursVerifier.disabled = false;
      bCoursTester.disabled = false;
      bCoursConfirmer.disabled = coursVerifie === null;
    }
  }

  champCours.addEventListener('input', () => {
    if (coursVerifie !== null && champCours.value !== coursVerifie) {
      coursVerifie = null;
      bCoursConfirmer.disabled = true;
      etatCours.textContent = 'Le texte a changé : vérifie-le à nouveau avant de confirmer.';
    }
  });

  bCoursVerifier.addEventListener('click', () => executerCours(async () => {
    coursVerifie = null;
    const texte = champCours.value;
    const v = await verifierCours(texte, await contexteCours());
    apercuCours.textContent = formaterApercu(v);
    apercuCours.hidden = false;
    if (v.ok) {
      coursVerifie = texte;
      etatCours.textContent = 'Vérifié : rien n\'est écrit. Appuie sur « Confirmer la leçon » pour l\'enseigner puis lancer les exercices.';
    } else {
      etatCours.textContent = 'Le bloc n\'est pas exécutable : corrige-le puis vérifie à nouveau.';
    }
  }));

  bCoursConfirmer.addEventListener('click', () => executerCours(async () => {
    const texte = champCours.value;
    if (coursVerifie === null || coursVerifie !== texte) {
      coursVerifie = null;
      etatCours.textContent = 'Vérifie d\'abord le texte actuel.';
      return;
    }
    coursVerifie = null;
    const res = await donnerCours(texte, await contexteCours());
    afficherRapport(res);
    etatCours.textContent = res.ok ? `Cours donné : ${res.verdict.texte}.` : 'Le bloc n\'est pas exécutable : rien n\'a été écrit.';
    await dessiner();
  }));

  bCoursTester.addEventListener('click', () => executerCours(async () => {
    const res = await testerCours(champCours.value, await contexteCours());
    afficherRapport(res);
    etatCours.textContent = res.ok ? `Test seulement (rien n'est écrit) : ${res.verdict.texte}.` : 'Le bloc n\'est pas exécutable.';
  }));

  bCoursCopier.addEventListener('click', async () => {
    try {
      await copier(dernierRapport);
      etatCours.textContent = 'Rapport copié : colle-le dans ChatGPT ou Claude.';
    } catch {
      etatCours.textContent = 'Copie impossible ici : sélectionne le texte du rapport ci-dessous et copie-le à la main.';
    }
  });

  // --- v0.17.7 : « Tester une hypothèse » — BANC D'ESSAI PROVISOIRE pour le pont induction → compréhension
  // (v0.17.6). Aucune logique d'induction ni de compréhension recopiée ici : induire() (induction.js,
  // inchangé) et apprendreGabaritType()/repondre() (esprit.js, inchangés) sont seulement APPELÉS.
  // « Plusieurs hypothèses SÛRES et DISJOINTES » n'est PAS un conflit : Confirmer les apprend TOUTES
  // sous la même signification, sans qu'aucun sélecteur d'hypothèse n'existe dans cette interface —
  // c'est déjà la garantie de induire() lui-même (r.hypotheses ne contient jamais deux entrées dont les
  // ensembles couverts se chevauchent ; un vrai chevauchement va dans r.conflits, jamais dans r.hypotheses).
  let dernierRapportInduction = null;

  function formaterRapportInduction(r) {
    const lignes = [];
    if (r.hypotheses.length) {
      lignes.push(`${r.hypotheses.length} hypothèse(s) sûre(s) :`);
      for (const h of r.hypotheses) lignes.push(`  [${h.candidats.join(' = ')}] couvre : ${h.couverture.join(' | ')}`);
    } else {
      lignes.push('Aucune hypothèse suffisamment soutenue.');
    }
    if (r.conflits.length) {
      lignes.push('', 'CONFLIT NON RÉSOLU (rien ne sera confirmé tant qu’il n’est pas levé) :');
      for (const c of r.conflits) for (const g of c.groupes) lignes.push(`  [${g.candidats.join(' = ')}] couvre : ${g.couvre.join(' | ')}`);
    }
    if (r.inexpliques.length) lignes.push('', 'Inexpliqué(s) : ' + r.inexpliques.join(' | '));
    return lignes.join('\n');
  }
  function lignesDe(el) { return el.value.split('\n').map((l) => l.trim()).filter(Boolean); }

  bInductionLancer.addEventListener('click', async () => {
    const positifs = lignesDe(champInductionPositifs);
    const negatifs = lignesDe(champInductionNegatifs);
    dernierRapportInduction = null;
    bInductionConfirmer.disabled = true;
    if (!positifs.length) { etatInduction.textContent = 'Il faut au moins une phrase positive.'; rapportInduction.hidden = true; bInductionAnnuler.disabled = true; return; }
    const e = await assurer();
    const r = induire(positifs, negatifs, { lexique: e.lexique });
    rapportInduction.textContent = formaterRapportInduction(r);
    rapportInduction.hidden = false;
    bInductionAnnuler.disabled = false;
    const confirmable = r.hypotheses.length > 0 && r.conflits.length === 0;
    if (confirmable) dernierRapportInduction = r;
    bInductionConfirmer.disabled = !confirmable;
    etatInduction.textContent = confirmable
      ? `${r.hypotheses.length} hypothèse(s) trouvée(s) : rien n'est encore écrit.`
      : r.conflits.length ? 'Conflit non résolu : rien à confirmer.' : 'Aucune hypothèse assez soutenue : rien à confirmer.';
  });

  bInductionConfirmer.addEventListener('click', async () => {
    if (!dernierRapportInduction || !dernierRapportInduction.hypotheses.length) return;
    const signification = champInductionSignification.value.trim();
    if (!signification) { etatInduction.textContent = 'Il faut un nom pour la signification visée.'; return; }
    const e = await assurer();
    for (const h of dernierRapportInduction.hypotheses) {
      await apprendreGabaritType(e, { candidats: h.candidats, gabarits: h.gabarits, signification, exemples: h.couverture });
    }
    etatInduction.textContent = `Confirmé : ${dernierRapportInduction.hypotheses.length} hypothèse(s) apprise(s) sous « ${signification} ».`;
    dernierRapportInduction = null;
    bInductionConfirmer.disabled = true;
    bInductionAnnuler.disabled = true;
  });

  bInductionAnnuler.addEventListener('click', () => {
    dernierRapportInduction = null;
    bInductionConfirmer.disabled = true;
    bInductionAnnuler.disabled = true;
    etatInduction.textContent = 'Annulé : rien n\'a été écrit.';
    rapportInduction.hidden = true;
  });

  bInductionTestLancer.addEventListener('click', async () => {
    const texte = champInductionTestTexte.value.trim();
    if (!texte) { resultatInductionTest.textContent = ''; return; }
    const e = await assurer();
    const r = repondre(e, texte);
    resultatInductionTest.textContent = `type = ${r.comprehension.type}`;
  });

  // --- DIAGNOSTIC PROVISOIRE (B1) : « Voir les expériences » ---------------------------------------
  // LECTURE SEULE, volontairement : appelle uniquement magasin.lireTout('experiences'), déjà utilisé
  // ailleurs pour lire — aucune nouvelle fonction de production, aucune écriture, aucun apprentissage,
  // aucun changement du comportement conversationnel. Pourra disparaître dès qu'un vrai écran existera.
  function formaterExperiences(liste) {
    if (!liste.length) return 'Aucune expérience conservée pour l’instant.';
    const lignes = [`${liste.length} expérience(s) :`, ''];
    for (const exp of [...liste].sort((a, b) => (a.date < b.date ? 1 : -1))) {
      lignes.push(`— ${exp.date}`);
      lignes.push(`  id : ${exp.id}`);
      lignes.push(`  reçu : « ${exp.texteRecu} »`);
      lignes.push(`  répondu : « ${exp.texteRepondu} »`);
      lignes.push(`  source : ${exp.source}`);
      lignes.push(`  référence mémoire : ${exp.referenceMemoire ? `idQuestion=${exp.referenceMemoire.idQuestion}, idReponse=${exp.referenceMemoire.idReponse}` : 'aucune'}`);
      lignes.push(`  interprétation(s) : ${exp.interpretations.length}`);
      for (const interp of exp.interpretations) {
        lignes.push(`    - origine=${interp.origine} : ${JSON.stringify(interp.donnees)}`);
      }
      lignes.push('');
    }
    return lignes.join('\n').trimEnd();
  }

  bExperiencesLister.addEventListener('click', async () => {
    const e = await assurer();
    const liste = await e.magasin.lireTout('experiences');
    rapportExperiences.textContent = formaterExperiences(liste);
    rapportExperiences.hidden = false;
    etatExperiences.textContent = `${liste.length} expérience(s) trouvée(s).`;
  });

  // === SÉLECTION D'EXPÉRIENCES POUR L'INDUCTION (pont B1 -> banc d'essai existant, v0.17.7) ===
  // Ne retape jamais aucune phrase : les identifiants d'expériences (copiés depuis « Voir les
  // expériences » ci-dessus) sont résolus par preparerEntreesInduction() (connaissances.js, pure,
  // lecture seule, inchangée dans ce chantier), puis les VRAIS champs du banc d'essai d'induction
  // déjà existant (au-dessus) sont simplement remplis. Aucun second moteur d'induction : ce bloc
  // n'appelle jamais induire() lui-même — seulement Lancer/Confirmer/Annuler, déjà câblés plus haut,
  // le font. Une expérience non désignée (ni positive ni négative) n'a AUCUN effet : elle n'entre
  // jamais implicitement dans les négatifs par complément — décision explicite de Christophe.
  function analyserIds(texte) {
    return texte.split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
  }

  bSelectionEnvoyer.addEventListener('click', async () => {
    const idsPositifs = analyserIds(champSelectionPositifs.value);
    const idsNegatifs = analyserIds(champSelectionNegatifs.value);
    if (!idsPositifs.length) { etatSelection.textContent = 'Il faut au moins un identifiant d’expérience positive.'; return; }
    const e = await assurer();
    try {
      const { positifs, negatifs } = await preparerEntreesInduction(e.magasin, { idsPositifs, idsNegatifs });
      champInductionPositifs.value = positifs.join('\n');
      champInductionNegatifs.value = negatifs.join('\n');
      etatSelection.textContent = `${positifs.length} positif(s), ${negatifs.length} négatif(s) envoyé(s) au banc d'essai — rien n'est encore lancé.`;
    } catch (err) {
      etatSelection.textContent = `Une expérience désignée est introuvable : ${err.message}`;
    }
  });

  // === REPÉRAGE DE MOTIFS RÉCURRENTS SUR TOUT LE VÉCU B1 (B3a, v0.17.10) ===
  // Outil de VALIDATION, en LECTURE SEULE : contrairement au bloc de sélection ci-dessus, Christophe
  // ne choisit AUCUNE expérience — data-langage-motifs-lister lit systématiquement TOUTES les
  // expériences B1 via magasin.lireTout('experiences'), ne garde que {id, texteRecu}, et appelle le
  // vrai repererMotifs() (induction.js, inchangée dans ce chantier) avec le lexique COURANT de
  // l'esprit. Recalculé intégralement à chaque clic : rien n'est persisté. N'appelle jamais induire()
  // ni apprendreGabaritType(), n'écrit rien dans B1 ni dans les connaissances, n'élimine aucun motif
  // trivial, ne donne aucune signification, ne se déclenche jamais tout seul.
  const bMotifsLister = $('[data-langage-motifs-lister]');
  const etatMotifs = $('[data-langage-motifs-etat]');
  const rapportMotifs = $('[data-langage-motifs-rapport]');
  // v0.24 — RACCORD « EXPÉRIENCES → INDUCTION » (décision ChatGPT du 27/09/2026) : Christophe choisit
  // un motif déjà affiché ci-dessus par son numéro, et ce bouton remplit le VRAI banc d'essai
  // d'induction déjà existant (data-langage-induction-positifs/negatifs, inchangé) — sans retaper
  // aucune phrase, sans appeler induire() lui-même (voir plus bas : c'est toujours le VRAI bouton
  // « Lancer l'induction » qui le fait).
  const champMotifsNumero = $('[data-langage-motifs-numero]');
  const bMotifsUtiliser = $('[data-langage-motifs-utiliser]');
  const etatMotifsUtiliser = $('[data-langage-motifs-utiliser-etat]');
  const bHypothesesFormer = $('[data-langage-hypotheses-former]');
  const etatHypotheses = $('[data-langage-hypotheses-etat]');
  const rapportHypotheses = $('[data-langage-hypotheses-rapport]');
  const bHypothesesLister = $('[data-langage-hypotheses-lister]');
  const rapportHypothesesListe = $('[data-langage-hypotheses-liste-rapport]');
  const champConfronterHypothese = $('[data-langage-hypotheses-confronter-hypothese]');
  const champConfronterExperience = $('[data-langage-hypotheses-confronter-experience]');
  const bHypothesesConfronter = $('[data-langage-hypotheses-confronter]');
  const etatConfronter = $('[data-langage-hypotheses-confronter-etat]');
  const champJugerExperience = $('[data-langage-hypotheses-juger-experience]');
  const bHypothesesJuger = $('[data-langage-hypotheses-juger-correct]');
  const bHypothesesJugerIncorrect = $('[data-langage-hypotheses-juger-incorrect]');
  const etatJuger = $('[data-langage-hypotheses-juger-etat]');

  // Constat de variation d'état (cadrage ChatGPT du 26/09/2026) : réutilise TEL QUEL
  // motifsAvecVariationDEtat() (induction.js, pure, inchangée par ce chantier). Un ensemble de clés
  // déjà retenues sert seulement à annoter chaque ligne du rapport -- « variation d'état : oui/non »
  // -- un CONSTAT, jamais un jugement : un motif toujours compris n'est pas déclaré sans intérêt, un
  // motif variable n'est pas déclaré important. Aucun tri, aucun filtrage du rapport lui-même : tous
  // les motifs restent affichés, dans le même ordre qu'avant ce chantier.
  function formaterMotifs(motifs) {
    if (!motifs.length) return 'Aucun motif récurrent constaté pour l’instant.';
    const clesAvecVariation = new Set(motifsAvecVariationDEtat(motifs).map((m) => m.cle));
    const lignes = [`${motifs.length} motif(s) constaté(s) :`, ''];
    // v0.24 — numéro affiché (« numéro : N ») pour désigner un motif au nouveau champ « Utiliser ce
    // motif pour l'induction » ci-dessous, SANS toucher la ligne « — <cle> » elle-même (garde-fou
    // épinglé, tests/repere-motifs-ecran.test.mjs, test « motifs triviaux affichés »).
    let numero = 0;
    for (const m of motifs) {
      numero += 1;
      lignes.push(`— ${m.cle}`);
      lignes.push(`  numéro : ${numero}`);
      lignes.push(`  couverture : ${m.couverture.length} expérience(s)`);
      lignes.push(`  ids : ${m.couverture.join(', ')}`);
      if (m.chronologie && m.chronologie.length) {
        lignes.push('  chronologie (séquence historique observée, sans jugement) :');
        for (const groupe of m.chronologie) {
          const etats = groupe.observations.map((o) => o.etat).join(', ');
          lignes.push(`    ${groupe.date} : ${etats}`);
        }
      }
      if (m.nonResolues && m.nonResolues.length) {
        lignes.push(`  observations non résolues (date absente/invalide ou expérience introuvable) : ${m.nonResolues.length}`);
      }
      lignes.push(`  compris : ${m.parEtat.compris.length}`);
      lignes.push(`  partiel : ${m.parEtat.partiel.length}`);
      lignes.push(`  incompris : ${m.parEtat.incompris.length}`);
      lignes.push(`  inconnu : ${m.parEtat.inconnu.length}`);
      lignes.push(`  variation d'état : ${clesAvecVariation.has(m.cle) ? 'oui (états différents observés)' : 'non'}`);
      if (m.distinction) {
        lignes.push('  comparaison des expériences (mêmes clés déjà enregistrées par comprendre()) :');
        for (const champ of ['sujet', 'relation', 'type', 'motsInconnus']) {
          const d = m.distinction[champ];
          const valeursDistinctes = [...new Set(d.valeurs.map((v) => JSON.stringify(v.valeur)))].map((s) => JSON.parse(s));
          lignes.push(`    ${champ} : ${d.identique ? 'identique' : 'différent'} (${valeursDistinctes.map((v) => JSON.stringify(v)).join(', ')})`);
        }
        if (m.nonResoluesComparaison && m.nonResoluesComparaison.length) {
          lignes.push(`    (${m.nonResoluesComparaison.length} observation(s) sans interprétation 'comprendre' exclue(s) de cette comparaison)`);
        }
      }
      lignes.push('');
    }
    return lignes.join('\n').trimEnd();
  }

  // Constat de la répartition par état ET de la chronologie brute (feu verts « répartition des
  // motifs par état de compréhension » puis « chronologie brute des états de compréhension ») --
  // résout ici, et SEULEMENT ici, la date réelle et l'état COMPRIS/PARTIEL/INCOMPRIS de chaque
  // expérience, à partir de sa PROPRE date B1 et de sa PROPRE interprétation d'origine 'comprendre'
  // (jamais recalculé, jamais un second appel à comprendre()/repondre(), jamais Date.now()) :
  // induction.js reste totalement ignorant de ce schéma. Une expérience sans interprétation
  // 'comprendre' (rien ne l'empêche, le schéma est libre) est explicitement INCONNUE -- jamais
  // implicitement COMPRISE.
  // v suivante — étend cette même résolution (jamais un second appel à comprendre()/repondre(),
  // jamais recalculé) aux champs déjà déterminés par comprendre() et déjà stockés tels quels dans
  // l'interprétation 'comprendre' : sujet, relation, type, motsInconnus -- exactement ce que la
  // comparaison factuelle (comparerMotifs(), induction.js) reçoit comme table DÉJÀ RÉSOLUE.
  function infoParIdDepuis(liste) {
    return new Map(liste.map((exp) => {
      const interp = exp.interpretations.find((i) => i.origine === 'comprendre');
      const d = interp ? interp.donnees : {};
      return [exp.id, {
        date: exp.date, etat: d.etat, sujet: d.sujet, relation: d.relation, type: d.type, motsInconnus: d.motsInconnus,
      }];
    }));
  }

  // RÉSOLUTION DU JUGEMENT EXTÉRIEUR (étape D refondée, décision ChatGPT du 26/09/2026) — un
  // jugement est FACULTATIF (rien n'est fabriqué pour une expérience jamais jugée : elle est
  // simplement absente de la table) et APPEND-ONLY (voir connaissances.js) : plusieurs jugements
  // peuvent exister pour la même expérience si Christophe se corrige ; celui qui compte ici est le
  // DERNIER ajouté (l'ordre d'ajout, jamais recalculé). Jamais lu depuis 'comprendre' : ce champ
  // n'existe QUE dans les interprétations d'origine 'jugement-christophe'.
  function jugementParIdDepuis(liste) {
    const carte = new Map();
    for (const exp of liste) {
      const jugements = exp.interpretations.filter((i) => i.origine === 'jugement-christophe');
      if (jugements.length) carte.set(exp.id, jugements[jugements.length - 1].donnees.jugement);
    }
    return carte;
  }

  // v0.24 — le motif choisi (par numéro) et le pool exact qui a servi à le repérer, gardés le temps
  // de la session d'écran pour le bouton « Utiliser ce motif » ci-dessous. JAMAIS persisté (ni
  // magasin ni mémoire ailleurs que cette fermeture) : un simple relais entre deux clics du MÊME
  // panneau, recalculé intégralement à chaque « Repérer les motifs », exactement comme rapportMotifs.
  let derniersMotifs = [];
  let dernierPoolMotifs = [];

  bMotifsLister.addEventListener('click', async () => {
    const e = await assurer();
    const liste = await e.magasin.lireTout('experiences');
    // v0.24 — pool borné aux expériences les PLUS RÉCENTES (jamais toute l'histoire de Naissance) :
    // seul ce qui alimente repererMotifs() ET le futur positifs/négatifs est borné ; infoParIdDepuis
    // ci-dessous continue de résoudre sur TOUTE la liste (un sur-ensemble sans effet, aucun id hors
    // du pool borné n'étant jamais référencé par les motifs qui en résultent).
    const poolRecent = poolExperiencesRecentes(liste);
    const entrees = poolRecent.map((exp) => ({ id: exp.id, texteRecu: exp.texteRecu }));
    const motifs = repererMotifs(entrees, { lexique: e.lexique });
    const infos = infoParIdDepuis(liste);
    const etatParId = new Map([...infos].map(([id, info]) => [id, info.etat]));
    const repartis = repartirMotifsParEtat(motifs, etatParId);
    const chronologies = chronologieMotifs(motifs, infos);
    const comparaisons = comparerMotifs(motifs, infos);
    const fusionnes = repartis.map((m, i) => ({
      ...m,
      chronologie: chronologies[i].chronologie,
      nonResolues: chronologies[i].nonResolues,
      distinction: comparaisons[i].distinction,
      nonResoluesComparaison: comparaisons[i].nonResolues,
    }));
    derniersMotifs = fusionnes;
    dernierPoolMotifs = entrees;
    rapportMotifs.textContent = formaterMotifs(fusionnes);
    rapportMotifs.hidden = false;
    etatMotifs.textContent = `${motifs.length} motif(s) constaté(s) parmi ${entrees.length} expérience(s) récente(s) (sur ${liste.length} au total), sans aucune sélection.`;
  });

  // v0.24 — RACCORD « EXPÉRIENCES → INDUCTION » : Christophe désigne un motif par son numéro (affiché
  // par « Repérer les motifs » ci-dessus, jamais deviné), et ce bouton remplit le VRAI banc d'essai
  // d'induction déjà existant avec positifsEtNegatifsDepuisMotif() (induction.js, pure) — positifs =
  // expériences couvertes par ce motif, négatifs = LE RESTE du même pool borné. N'appelle JAMAIS
  // induire() ni apprendreGabaritType() lui-même : c'est ensuite, comme toujours, le VRAI bouton
  // « Lancer l'induction » puis « Confirmer » (inchangés) qui font ce travail. Les jugements
  // correct/incorrect n'entrent pour rien ici (pipeline distinct, inchangé).
  bMotifsUtiliser.addEventListener('click', () => {
    const n = Number.parseInt(champMotifsNumero.value, 10);
    if (!derniersMotifs.length) {
      etatMotifsUtiliser.textContent = 'Clique d’abord « Repérer les motifs » pour avoir des numéros à choisir.';
      return;
    }
    if (!Number.isInteger(n) || n < 1 || n > derniersMotifs.length) {
      etatMotifsUtiliser.textContent = `Numéro invalide : indique un motif entre 1 et ${derniersMotifs.length}.`;
      return;
    }
    const motif = derniersMotifs[n - 1];
    const { positifs, negatifs } = positifsEtNegatifsDepuisMotif(motif, dernierPoolMotifs);
    champInductionPositifs.value = positifs.join('\n');
    champInductionNegatifs.value = negatifs.join('\n');
    etatMotifsUtiliser.textContent = `Motif « ${motif.cle} » chargé dans le banc d'essai ci-dessus : ${positifs.length} positif(s), ${negatifs.length} négatif(s) — choisis une signification puis clique « Lancer l'induction ».`;
  });

  // === FORMATION ET PERSISTANCE D'HYPOTHÈSES SUR JUGEMENT (étape D refondée, décision ChatGPT du
  // 26/09/2026, « SIGNAL D'APPRENTISSAGE ») === Réutilise repererMotifs() (sur le texte SEUL, sans
  // jamais appeler comprendre()) et jugementParIdDepuis() ci-dessus : aucune seconde source de
  // vérité. formerHypothesesJugement() (induction.js, pure) ne fait que CONSTATER une co-variation
  // entre un motif et un jugement humain déjà donné ; enregistrerHypotheseSiNouvelle()
  // (connaissances.js) est ce qui persiste, idempotent -- une hypothèse déjà connue n'est jamais
  // recréée ni écrasée par ce bouton.
  // MISE À JOUR (chantier « FIN DES FONDATIONS », décision ChatGPT du 26/09/2026) : la formation
  // n'est PLUS un clic manuel obligatoire -- connaissances.js réexamine désormais lui-même tout le
  // vécu automatiquement à chaque jugement (examinerVecuEtFormerHypotheses(), déclenchée par
  // confronterJugementEtEnregistrer()), aussi bien depuis ce laboratoire que depuis la conversation
  // réelle. Ce bouton devient un outil de DIAGNOSTIC (revoir/déclencher un réexamen à la demande),
  // jamais une dépendance fonctionnelle. Le garde-fou STATIQUE (tests/motifs-recurrents.test.mjs)
  // continue d'interdire tout appel à repererMotifs depuis pont.js (créer une expérience seule ne
  // déclenche jamais de formation) ; côté connaissances.js, il autorise désormais précisément
  // l'appel fait depuis examinerVecuEtFormerHypotheses -- jamais un déclenchement caché : il ne se
  // produit qu'en conséquence directe d'un jugement que Christophe a lui-même donné.
  function formaterHypothesesFormees(hypotheses) {
    if (!hypotheses.length) return 'Aucune hypothèse formée : aucun motif ne couvre encore d’expérience jugée.';
    const lignes = [`${hypotheses.length} hypothèse(s) formée(s) ou déjà connue(s) :`, ''];
    for (const h of hypotheses) {
      lignes.push(`— ${h.objet.id}`);
      lignes.push(`  motif : ${h.objet.motifCle}`);
      lignes.push(`  provenance (expériences jugées) : ${h.objet.provenance.join(', ')}`);
      lignes.push(`  attente : ${h.objet.attente == null ? 'aucune (jugements divergents)' : h.objet.attente}`);
      lignes.push(`  état : ${h.objet.etatHypothese}${h.nouvelle ? ' (nouvellement formée)' : ' (déjà connue, inchangée)'}`);
      lignes.push('');
    }
    return lignes.join('\n').trimEnd();
  }

  bHypothesesFormer.addEventListener('click', async () => {
    const e = await assurer();
    const liste = await e.magasin.lireTout('experiences');
    const entrees = liste.map((exp) => ({ id: exp.id, texteRecu: exp.texteRecu }));
    const motifs = repererMotifs(entrees, { lexique: e.lexique });
    const jugements = jugementParIdDepuis(liste);
    const pures = formerHypothesesJugement(motifs, jugements);
    const resultats = [];
    for (const pure of pures) {
      const avant = (await e.magasin.lireTout('hypotheses')).some((h) => h.id === pure.id);
      const objet = await enregistrerHypotheseSiNouvelle(e.magasin, pure);
      resultats.push({ objet, nouvelle: !avant });
    }
    rapportHypotheses.textContent = formaterHypothesesFormees(resultats);
    rapportHypotheses.hidden = false;
    const nouvelles = resultats.filter((r) => r.nouvelle).length;
    etatHypotheses.textContent = `${resultats.length} hypothèse(s) constatée(s) (${nouvelles} nouvelle(s)), sans aucune sélection.`;
  });

  // === LISTE DES HYPOTHÈSES DÉJÀ PERSISTÉES — lecture seule, aucun recalcul ===
  function formaterListeHypotheses(toutes) {
    if (!toutes.length) return 'Aucune hypothèse persistée pour l’instant.';
    const lignes = [`${toutes.length} hypothèse(s) persistée(s) :`, ''];
    for (const h of toutes) {
      lignes.push(`— ${h.id}`);
      lignes.push(`  motif : ${h.motifCle}`);
      lignes.push(`  attente : ${h.attente == null ? 'aucune (jugements divergents)' : h.attente}`);
      lignes.push(`  état : ${h.etatHypothese}`);
      lignes.push(`  observations : ${h.observations.length}`);
      lignes.push(`  confrontations : ${h.confrontations.length}`);
      lignes.push('');
    }
    return lignes.join('\n').trimEnd();
  }

  bHypothesesLister.addEventListener('click', async () => {
    const e = await assurer();
    const toutes = await e.magasin.lireTout('hypotheses');
    rapportHypothesesListe.textContent = formaterListeHypotheses(toutes);
    rapportHypothesesListe.hidden = false;
  });

  // === POSER UNE ATTENTE SUR UNE EXPÉRIENCE, PUIS LA JUGER (étape D, diagnostic manuel) ===
  // Reproduit à la main, pour validation téléphone, exactement ce que le branchement conversation
  // normale (pont.js) fait automatiquement (voir reconnaitreAttentesPourExperience ci-dessous) :
  // poser une attente AVANT tout jugement (enregistrerAttenteSiPertinente refuse mécaniquement
  // l'ordre inverse), puis juger l'expérience -- ce qui confronte automatiquement toute attente déjà
  // posée (confronterJugementEtEnregistrer, connaissances.js).
  bHypothesesConfronter.addEventListener('click', async () => {
    const e = await assurer();
    const idHypothese = (champConfronterHypothese.value || '').trim();
    const idExperience = (champConfronterExperience.value || '').trim();
    const toutes = await e.magasin.lireTout('hypotheses');
    const hypothese = toutes.find((h) => h.id === idHypothese);
    if (!hypothese) { etatConfronter.textContent = `Aucune hypothèse « ${idHypothese} » à confronter.`; return; }
    try {
      await enregistrerAttenteSiPertinente(e.magasin, idExperience, hypothese);
    } catch (err) {
      etatConfronter.textContent = err.message;
      return;
    }
    etatConfronter.textContent = hypothese.attente == null
      ? `Aucune attente univoque pour « ${idHypothese} » : rien à poser.`
      : `Attente « ${hypothese.attente} » posée sur « ${idExperience} », en attente du jugement de Christophe.`;
  });

  // === JUGER UNE EXPÉRIENCE (« correct »/« incorrect ») — signal FACULTATIF, jamais déduit ===
  // Depuis le chantier « FIN DES FONDATIONS » (décision ChatGPT du 26/09/2026), juger une expérience
  // déclenche AUSSI, automatiquement, un réexamen complet du vécu (examinerVecuEtFormerHypotheses,
  // connaissances.js, appelée à l'intérieur de confronterJugementEtEnregistrer) : le clic manuel
  // « Former des hypothèses » n'est plus nécessaire au fonctionnement, seulement un outil de
  // diagnostic. `nouvellesHypothesesDepuis` compare la table AVANT/APRÈS pour l'afficher ici --
  // jamais pour décider quoi que ce soit, uniquement pour rendre l'automatisme observable.
  async function nouvellesHypothesesDepuis(magasin, avantIds, action) {
    await action();
    const apres = await magasin.lireTout('hypotheses');
    return apres.filter((h) => !avantIds.has(h.id));
  }
  bHypothesesJuger.addEventListener('click', async () => {
    const e = await assurer();
    const idExperience = (champJugerExperience.value || '').trim();
    try {
      const avantIds = new Set((await e.magasin.lireTout('hypotheses')).map((h) => h.id));
      let resultats;
      const nouvelles = await nouvellesHypothesesDepuis(e.magasin, avantIds, async () => {
        resultats = await confronterJugementEtEnregistrer(e.magasin, idExperience, 'correct', e.lexique);
      });
      const base = resultats.length
        ? `Jugement « correct » enregistré. Confrontation(s) : ${resultats.map((r) => r.resultat).join(', ')}.`
        : 'Jugement « correct » enregistré. Aucune attente n’avait été posée sur cette expérience.';
      etatJuger.textContent = nouvelles.length
        ? `${base} ${nouvelles.length} nouvelle(s) hypothèse(s) formée(s) automatiquement (${nouvelles.map((h) => h.motifCle).join(', ')}).`
        : base;
    } catch (err) { etatJuger.textContent = err.message; }
  });
  bHypothesesJugerIncorrect.addEventListener('click', async () => {
    const e = await assurer();
    const idExperience = (champJugerExperience.value || '').trim();
    try {
      const avantIds = new Set((await e.magasin.lireTout('hypotheses')).map((h) => h.id));
      let resultats;
      const nouvelles = await nouvellesHypothesesDepuis(e.magasin, avantIds, async () => {
        resultats = await confronterJugementEtEnregistrer(e.magasin, idExperience, 'incorrect', e.lexique);
      });
      const base = resultats.length
        ? `Jugement « incorrect » enregistré. Confrontation(s) : ${resultats.map((r) => r.resultat).join(', ')}.`
        : 'Jugement « incorrect » enregistré. Aucune attente n’avait été posée sur cette expérience.';
      etatJuger.textContent = nouvelles.length
        ? `${base} ${nouvelles.length} nouvelle(s) hypothèse(s) formée(s) automatiquement (${nouvelles.map((h) => h.motifCle).join(', ')}).`
        : base;
    } catch (err) { etatJuger.textContent = err.message; }
  });

  // === BRANCHEMENT CONVERSATION NORMALE (étape E) — appelée par pont.js après CHAQUE nouvelle
  // expérience B1 réelle, avant tout jugement. NE recalcule PAS les motifs récurrents (repererMotifs()
  // reste strictement derrière le clic manuel de Christophe -- voir tests/motifs-recurrents.test.mjs) :
  // se contente de tester la NOUVELLE expérience contre les hypothèses DÉJÀ persistées, une par une,
  // avec contientGabarit()/representerExemple() (induction.js, primitives déjà publiques, jamais
  // repererMotifs()). Pour chaque hypothèse dont le motif correspond ET qui porte une attente
  // univoque, pose l'attente (enregistrerAttenteSiPertinente, idempotente, refuse tout jugement déjà
  // là). N'écrit ni ne forme aucune hypothèse ici : la formation reste le clic manuel ci-dessus.
  async function reconnaitreAttentesPourExperience(idExperience) {
    const e = await assurer();
    const toutes = await e.magasin.lireTout('experiences');
    const experience = toutes.find((x) => x.id === idExperience);
    if (!experience) return [];
    const representee = representerExemple(experience.texteRecu, e.lexique);
    const hypotheses = (await e.magasin.lireTout('hypotheses')).filter((h) => h.attente != null && h.gabarit);
    const posees = [];
    for (const h of hypotheses) {
      if (!contientGabarit(representee, h.gabarit)) continue;
      await enregistrerAttenteSiPertinente(e.magasin, idExperience, h);
      posees.push(h.id);
    }
    return posees;
  }

  // === PROPOSITION SPONTANÉE (v0.25, décision ChatGPT du 27/09/2026) =============================
  // BRANCHEMENT CONVERSATION NORMALE : appelée par main.js (via le MÊME point apresNouvelleExperience
  // que reconnaitreAttentesPourExperience ci-dessus) après CHAQUE nouvelle expérience B1 réelle.
  // Réutilise EXACTEMENT l'infrastructure v0.24 (poolExperiencesRecentes/repererMotifs/
  // positifsEtNegatifsDepuisMotif, induction.js, inchangées) plus candidatDepuisMotif() (v0.25,
  // induction.js, pure) pour décider QUAND une régularité est assez sûre pour être proposée --
  // n'écrit JAMAIS dans gabaritsTypes ici (aucun apprentissage silencieux : seule
  // confirmerPropositionSpontanee() ci-dessous le fait, et seulement après la réponse EXPLICITE de
  // Christophe). Rend AU PLUS une proposition à la fois :
  //  - s'il existe déjà une proposition 'proposee' non tranchée, la retourne TELLE QUELLE (jamais une
  //    seconde proposition empilée par-dessus -- garantie qui survit même à un redémarrage complet,
  //    puisqu'elle vit dans la table `propositions`, pas dans une variable en mémoire de main.js) ;
  //  - sinon, examine les motifs du vécu récent et rend le PREMIER candidat réellement nouveau :
  //    ni déjà proposé/refusé/appris sous la même empreinte (cleCandidat() -- candidats+couverture,
  //    jamais le simple motif de départ, pour qu'un refus ne bloque pas éternellement le motif si le
  //    vécu évolue ensuite), ni déjà appris par un AUTRE chemin (le banc d'essai manuel du
  //    laboratoire, vérifié directement contre gabaritsTypes/statut 'validee').
  async function examinerPropositionSpontanee() {
    const e = await assurer();
    const dejaTraitees = await e.magasin.lireTout('propositions');
    const enAttente = dejaTraitees.find((p) => p.statut === 'proposee');
    if (enAttente) return enAttente;
    const idsConnus = new Set(dejaTraitees.map((p) => p.id));
    const signaturesApprises = new Set(
      e.gabaritsTypesAppris.filter((g) => g.statut === 'validee').map((g) => [...g.candidats].sort().join('|')),
    );
    const toutesExperiences = await e.magasin.lireTout('experiences');
    const pool = poolExperiencesRecentes(toutesExperiences.map((x) => ({ id: x.id, texteRecu: x.texteRecu, date: x.date })));
    const motifs = repererMotifs(pool, { lexique: e.lexique });
    // Plusieurs motifs de départ DIFFÉRENTS peuvent mener au MÊME candidat (même empreinte : mêmes
    // candidats, même couverture) -- dédupliqué ici (Map par empreinte) pour ne jamais l'examiner
    // deux fois. Quand plusieurs candidats RÉELLEMENT DISTINCTS qualifient à la fois (rare, un vécu
    // encore petit peut porter plusieurs régularités simultanées, ex. un motif spécifique à un seul
    // sujet ET un motif plus large qui le recouvre), retient celui à la couverture la plus large --
    // le plus soutenu par le vécu, même principe que induire() lui-même (couverture avant tout,
    // JAMAIS un choix arbitraire non justifié) -- pas de tri plus fin que ça (« pas d'heuristique
    // compliquée », décision ChatGPT du 27/09/2026).
    const candidatsParEmpreinte = new Map();
    for (const motif of motifs) {
      const candidat = candidatDepuisMotif(motif, pool, { lexique: e.lexique });
      if (!candidat || candidatsParEmpreinte.has(candidat.empreinte)) continue;
      const signature = [...candidat.hypothese.candidats].sort().join('|');
      if (signaturesApprises.has(signature) || idsConnus.has(candidat.empreinte)) continue;
      candidatsParEmpreinte.set(candidat.empreinte, candidat);
    }
    let meilleur = null;
    for (const candidat of candidatsParEmpreinte.values()) {
      if (!meilleur || candidat.hypothese.couverture.length > meilleur.hypothese.couverture.length) meilleur = candidat;
    }
    if (!meilleur) return null;
    return proposerCandidatSiNouveau(e.magasin, meilleur);
  }

  // CONFIRMATION D'UNE PROPOSITION EN ATTENTE (même décision) : Christophe a donné un nom -- déclenche
  // le VRAI apprentissage (apprendreGabaritType(), esprit.js, inchangée, exactement comme le bouton
  // « Confirmer » du banc d'essai manuel), PUIS enregistre le sort du candidat (confirmerPropositionApprise,
  // connaissances.js) pour qu'il ne soit plus jamais reproposé.
  async function confirmerPropositionSpontanee(id, signification) {
    const e = await assurer();
    const proposition = (await e.magasin.lireTout('propositions')).find((p) => p.id === id && p.statut === 'proposee');
    if (!proposition) throw new Error(`Aucune proposition « ${id} » en attente à confirmer.`);
    const resultat = await apprendreGabaritType(e, {
      candidats: proposition.candidats, gabarits: proposition.gabarits, signification, exemples: proposition.couverture,
    });
    await confirmerPropositionApprise(e.magasin, id, resultat.objet.id);
    return resultat;
  }

  // REFUS D'UNE PROPOSITION EN ATTENTE (même décision) : n'écrit jamais dans gabaritsTypes, se
  // contente de marquer CE candidat précis 'refusee' (voir connaissances.js : un candidat
  // ultérieurement différent, issu d'un vécu qui a évolué, reste proposable).
  async function refuserPropositionSpontanee(id) {
    const e = await assurer();
    return refuserProposition(e.magasin, id);
  }

  // === TRANSFORMATIONS APPRISES PAR EXEMPLES (décision ChatGPT du 27/09/2026, « ÉDUQUER PLUTÔT QUE
  // PROGRAMMER ») ================================================================================
  // L'INDUCTION elle-même (induireTransformation(), transformation.js, pure) reste appelée
  // DIRECTEMENT par main.js -- exactement comme lireCours()/extraireLecon() le sont déjà pour les
  // autres canaux -- puisqu'elle ne touche à rien de l'esprit : rien à exposer ici pour ça.
  // Cette fonction-ci ne fait que PERSISTER une transformation DÉJÀ validée par main.js (candidat
  // proposé, puis confirmation explicite de Christophe -- « Valide la transformation. »), sur le
  // MÊME esprit partagé que le reste du langage.
  async function confirmerTransformation(candidat) {
    const e = await assurer();
    const resultat = await apprendreTransformation(e.magasin, {
      n: candidat.n,
      insertions: candidat.insertions,
      garder: candidat.garder,
      interne: candidat.interne,
      certaine: candidat.certaine,
      intention: candidat.intention,
      exemples: candidat.exemples,
    });
    // Même principe que apprendreRegle()/apprendreFait() (esprit.js) : l'esprit chargé une seule
    // fois (assurer(), en mémoire) doit refléter IMMÉDIATEMENT l'écriture, sans attendre un
    // rechargement complet -- sinon une application juste après la confirmation, dans la MÊME
    // session, ne verrait pas encore la transformation qu'on vient pourtant d'apprendre.
    const idx = e.transformations.findIndex((t) => t.id === resultat.objet.id);
    if (idx >= 0) e.transformations[idx] = resultat.objet; else e.transformations.push(resultat.objet);
    await dessiner();
    return resultat;
  }

  // APPLICATION LOCALE (« lui donner une phrase nouvelle ») : mobilise TOUTES les transformations
  // validées dont l'arité correspond à l'entrée -- une seule, plusieurs qui se combinent sans se
  // contredire (fusionnerTransformations(), transformation.js -- LE MÊME mécanisme que l'induction,
  // aucun second algorithme de composition), ou une abstention explicite si rien ne s'applique ou si
  // deux transformations apprises séparément se contredisent pour cette entrée précise -- jamais un
  // choix arbitraire. N'appelle jamais Gemini : c'est tout l'objet de ce chantier.
  // CORRECTIF (v0.28.1, décision ChatGPT « STOP ARCHITECTURAL : LOT 1 CASSE UNE COMPOSITION DÉJÀ
  // VALIDÉE ») : une transformation NON CERTAINE (LOT 1) est une connaissance encore insuffisamment
  // démontrée -- elle ne doit pas s'appliquer seule (déjà assuré par appliquerTransformation(), qui
  // renvoie null), et ne doit donc PAS non plus participer à une composition : sa seule coexistence,
  // par ailleurs légitime, avec des transformations CERTAINES de la même arité ne doit jamais empêcher
  // ces dernières de se combiner entre elles. Elle est donc exclue ICI, avant fusionnerTransformations
  // (qui reste inchangée), et non appliquée seule pour autant : elle reste apprise et persistée
  // (confirmerTransformation), et pourra un jour devenir certaine si de nouveaux exemples lèvent le
  // doute -- aucune notion de grammaire, un simple filtre sur un champ déjà calculé.
  // ÉLARGI (v0.29, décision ChatGPT « SÉLECTION CONTEXTUELLE PAR INTENTION ») : accumuler plusieurs
  // transformations légitimes de même arité mais de PORTÉE différente (ex. « féminin » et « pluriel »
  // sur des mots isolés) les mettait toutes en concurrence sans qu'aucune information ne permette de
  // choisir. `intentionDemandee` (fournie explicitement par l'appelant -- main.js, jamais déduite d'une
  // formulation naturelle) sélectionne, quand elle est précisée, UNIQUEMENT les transformations qui
  // portent EXACTEMENT cette intention (chaîne comparée par égalité stricte, jamais interprétée) ; le
  // MÊME mécanisme de fusion/composition ci-dessous s'applique ensuite à ce sous-ensemble, sans nouvel
  // algorithme. Une intention demandée mais qu'AUCUNE transformation de cette arité ne porte est une
  // abstention DISTINCTE (« intention_inconnue ») : jamais un retour silencieux vers les transformations
  // sans intention, qui pourrait donner l'illusion trompeuse que l'intention a été comprise. RÉTRO-
  // COMPATIBLE par construction : sans intention demandée (le cas de tous les usages d'avant ce
  // chantier), le comportement est STRICTEMENT inchangé -- toutes les transformations certaines de
  // cette arité participent, qu'elles portent une intention ou non.
  async function appliquerTransformationLocale(texte, intentionDemandee = null) {
    const e = await assurer();
    const jetons = tokeniser(texte);
    const memeArite = (e.transformations || []).filter((t) => t.statut === 'validee' && t.n === jetons.length && t.certaine !== false);
    let validees = memeArite;
    if (intentionDemandee != null && intentionDemandee !== '') {
      validees = memeArite.filter((t) => t.intention === intentionDemandee);
      if (!validees.length) {
        return { ok: false, raison: 'intention_inconnue', detail: `Aucune transformation apprise ne porte l'intention « ${intentionDemandee} » pour une entrée de ${jetons.length} mot(s).` };
      }
    }
    if (!validees.length) {
      return { ok: false, raison: 'aucune', detail: `Aucune transformation apprise ne s'applique à une entrée de ${jetons.length} mot(s).` };
    }
    const fusion = fusionnerTransformations(validees);
    if (!fusion.ok) {
      return { ok: false, raison: fusion.raison, detail: 'Plusieurs transformations apprises se contredisent pour cette entrée précise : je préfère ne pas choisir au hasard.' };
    }
    // LOT 1 (anti-sur-généralisation, décision ChatGPT « GRAND DIAGNOSTIC ») : une transformation (ou
    // une fusion) NON CERTAINE ne doit JAMAIS être appliquée silencieusement -- appliquerTransformation()
    // renvoie alors null par construction (transformation.js) ; ici, abstention EXPLICITE et honnête,
    // jamais confondue avec un succès à texte vide.
    if (fusion.transformation.certaine === false) {
      return { ok: false, raison: 'incertaine', detail: 'Les exemples appris ne permettent pas encore de distinguer une règle générale véritable d\'une variable qui n\'a simplement pas encore varié : je préfère m\'abstenir plutôt que risquer une généralisation abusive.' };
    }
    // v0.32 (décision ChatGPT « APPRENTISSAGE DU RETRAIT D'AFFIXES ») : un « retrait » interne
    // (transformation.js, appliquerTransformation) vérifie désormais RÉELLEMENT que le mot reçu porte
    // le préfixe ET le suffixe appris avant de les découper -- si ce n'est pas le cas, elle renvoie
    // null par construction (jamais un découpage aveugle). Ici aussi, abstention EXPLICITE et honnête,
    // jamais confondue avec un succès à texte vide (même discipline que pour `certaine === false`
    // au-dessus).
    const resultat = appliquerTransformation(fusion.transformation, texte);
    if (resultat == null) {
      return { ok: false, raison: 'retrait_incompatible', detail: 'Le mot reçu ne porte pas le préfixe et le suffixe appris : je préfère m\'abstenir plutôt que le découper à l\'aveugle.' };
    }
    return { ok: true, texte: resultat };
  }

  // RECONNAISSANCE DE PHRASE (v0.30, décision ChatGPT « RACCORDEMENT COMPRÉHENSION → INTENTION →
  // TRANSFORMATION ») : « Mets lent au féminin. » -- une phrase entière jamais tapée avant, sans
  // marqueur « Applique : » -- doit pouvoir être reconnue si (et SEULEMENT si) elle correspond
  // LITTÉRALEMENT au squelette fixe d'une transformation déjà enseignée avec une intention (voir
  // correspondSquelette(), transformation.js). AUCUN second moteur : la partie variable est « extraite »
  // en appliquant simplement cette MÊME transformation (son résultat EST la partie variable, par
  // construction -- v0.26/v0.27), puis appliquerTransformationLocale() (v0.29, inchangée) choisit et
  // applique la capacité correspondant à l'intention reconnue.
  // Seules les transformations VALIDÉES, CERTAINES et PORTANT UNE INTENTION participent (une
  // transformation sans intention n'est jamais un « squelette de phrase » à reconnaître tout seul --
  // elle reste utilisable via « Applique : » explicite, inchangé).
  // Renvoie { reconnu: false } si RIEN ne correspond -- CE N'EST JAMAIS UNE ERREUR : l'appelant doit
  // alors continuer EXACTEMENT le pipeline conversationnel habituel, sans aucun changement.
  // Renvoie { reconnu: true, ok, texte|raison, detail } dès qu'AU MOINS un squelette correspond : à
  // partir de là, la réponse est TOUJOURS locale (succès ou abstention explicite), plus jamais un
  // recours à Gemini/LFM2 pour cette phrase précise.
  async function tenterReconnaissanceTransformation(texte) {
    const e = await assurer();
    const candidates = (e.transformations || []).filter((t) => t.statut === 'validee'
      && t.certaine !== false
      && t.intention
      && correspondSquelette(t, texte));
    if (!candidates.length) return { reconnu: false };
    // Plusieurs squelettes reconnus mais d'INTENTIONS DIFFÉRENTES : jamais un choix arbitraire entre
    // deux lectures possibles de la même phrase -- abstention explicite, sans Gemini pour trancher.
    const intentions = new Set(candidates.map((t) => t.intention));
    if (intentions.size > 1) {
      return {
        reconnu: true,
        ok: false,
        raison: 'ambigu',
        detail: `Plusieurs intentions différentes (${[...intentions].join(', ')}) correspondent à cette formulation : je préfère ne pas choisir au hasard.`,
      };
    }
    // Plusieurs squelettes de la MÊME intention (plusieurs formulations apprises séparément) :
    // légitime -- mais s'ils extraient chacun une valeur DIFFÉRENTE pour cette même phrase, c'est une
    // ambiguïté réelle, jamais un choix arbitraire non plus.
    const [intention] = intentions;
    const valeurs = new Set(candidates.map((t) => appliquerTransformation(t, texte)).filter((v) => v != null));
    if (!valeurs.size) {
      return { reconnu: true, ok: false, raison: 'extraction_impossible', detail: 'Cette formulation est reconnue, mais je ne parviens pas à en extraire la partie variable.' };
    }
    if (valeurs.size > 1) {
      return { reconnu: true, ok: false, raison: 'ambigu', detail: 'Plusieurs interprétations différentes de cette formulation sont possibles : je préfère ne pas choisir au hasard.' };
    }
    const [valeur] = valeurs;
    const resultat = await appliquerTransformationLocale(valeur, intention);
    if (!resultat.ok) return { reconnu: true, ok: false, raison: resultat.raison, detail: resultat.detail };
    return { reconnu: true, ok: true, texte: resultat.texte };
  }

  // === ACTIONS APPRISES (LOT B3, v0.39.0, décision ChatGPT « RACCORD CONVERSATIONNEL ») ===========
  // PERSISTANCE D'UNE ACTION DÉJÀ ÉVALUÉE (candidat proposé par main.js via evaluerAction(), action.js,
  // PUIS confirmation explicite de Christophe — « Valide l'action. ») : même principe EXACT que
  // confirmerTransformation() ci-dessus. apprendreAction() (connaissances.js) peut, selon le cas,
  // fusionner dans une entrée existante OU remplacer plusieurs anciennes entrées à la fois (réenseignement
  // versionné) : contrairement à confirmerTransformation() (un seul objet à mettre à jour), on RECHARGE
  // ici la table entière depuis le magasin — la plus sûre façon de refléter IMMÉDIATEMENT, sur l'esprit
  // déjà en mémoire, TOUTE conséquence de l'écriture (nouvelle entrée, fusion, et toute ancienne entrée
  // passée à 'remplacee'), sans dupliquer la logique de versionnement déjà dans connaissances.js.
  async function confirmerAction(candidat) {
    const e = await assurer();
    const resultat = await apprendreAction(e.magasin, {
      operation: candidat.operation,
      roles: candidat.roles,
      n: candidat.n,
      exemples: candidat.exemples,
      statut: candidat.statut,
      origine: 'apprise-conversation',
    });
    e.actions = await e.magasin.lireTout('actions');
    await dessiner();
    return resultat;
  }

  // RECONNAISSANCE DE PHRASE (v0.39, LOT B3) : même principe EXACT que
  // tenterReconnaissanceTransformation() ci-dessus, pour les actions internes apprises (B2, action.js)
  // plutôt que pour les transformations. AUCUN mot français déclencheur codé en dur ici : la seule
  // question posée est structurelle -- « cette entrée correspond-elle au squelette d'une action déjà
  // VALIDÉE ? » (reconnaitreActions(), action.js, qui filtre déjà lui-même les actions 'incertaine'/
  // 'remplacee' -- jamais répété ici). Renvoie { reconnu: false } si RIEN ne correspond -- CE N'EST
  // JAMAIS UNE ERREUR : l'appelant continue EXACTEMENT le pipeline habituel, sans aucun changement
  // (priorité de sécurité « zéro action reconnue → pipeline actuel inchangé », cadrage B3). Dès qu'AU
  // MOINS une action validée correspond, la réponse est TOUJOURS locale à partir d'ici -- succès,
  // ambiguïté explicite, ou échec d'invocation -- JAMAIS un recours à Gemini pour cette phrase précise
  // (« abstention, jamais Gemini pour masquer l'échec de l'action locale », cadrage B3).
  async function tenterReconnaissanceAction(texte) {
    const e = await assurer();
    const reco = reconnaitreActions(e.actions || [], texte);
    if (reco.etat === 'aucune') return { reconnu: false };
    if (reco.etat === 'ambigu') {
      return {
        reconnu: true,
        ok: false,
        raison: 'ambigu',
        detail: `Plusieurs actions apprises correspondent à cette phrase : je préfère ne pas choisir au hasard (${reco.actions.map((a) => a.operation).join(', ')}).`,
      };
    }
    const { action } = reco;
    const invocation = invoquerAction(action, e, texte);
    if (!invocation.ok) {
      return { reconnu: true, ok: false, raison: invocation.raison, detail: 'Cette formulation est reconnue, mais je ne parviens pas à l\'invoquer localement.' };
    }
    // v0.43 — DÉCISION CHATGPT « RÉFÉRENÇABILITÉ ET RÉUTILISATION SCALAIRE DES RÉSULTATS » :
    // MÉCANISME 1 (conserver/référencer, composition.js) appliqué ICI de façon GÉNÉRIQUE, par le nom
    // d'opération déjà présent dans le registre -- aucune capacité particulière n'est nommée. Un
    // simple effet de bord, qui ne consulte jamais esprit.liaisons et ne déclenche jamais rien :
    // c'est ce qui permet à une invocation ORDINAIRE (la voie naturelle déjà existante, ci-dessus,
    // strictement inchangée sinon) de laisser son résultat référençable par une liaison, SANS qu'une
    // liaison existe ou non ne change quoi que ce soit à ce qui se passe ici.
    enregistrerResultat(e, action.operation, invocation.resultat);
    // v0.46 — OBSERVATION PASSIVE DES TENTATIVES DE RAISONNEMENT (chantier séparé, aucune autonomie
    // ajoutée) : une capacité a RÉELLEMENT été invoquée ICI (voie « action apprise reconnue en
    // conversation ») -- on en CONSERVE fidèlement une trace, un pur effet de bord supplémentaire,
    // exactement au même endroit que enregistrerResultat() ci-dessus, jamais un déclenchement de quoi
    // que ce soit d'autre. Sur cette voie, chaque argument vient TOUJOURS du texte reconnu (jamais
    // d'une liaison) : provenance 'texte' pour chaque rôle, sans qu'action.js n'ait besoin de le
    // savoir lui-même (il reste ignorant de ce qu'une trace est).
    const provenanceTexte = {};
    for (const role of Object.keys(invocation.arguments)) provenanceTexte[role] = 'texte';
    // v0.47 — CONTEXTE PRÉ-CHOIX : le texte REÇU ici (paramètre `texte`, disponible AVANT que
    // reconnaitreActions() ait désigné une action donc une capacité) et sa tokenisation générique,
    // capacité-agnostique (tokeniser(), déjà utilisée telle quelle par extraction.js/action.js —
    // aucun nouveau tokenizer). Ni capacité, ni rôle, ni résultat : seulement ce qui existait avant
    // le choix.
    // v0.53 — PROVENANCE POSITIONNELLE EXACTE (décision ChatGPT, 03/10/2026) : invoquerAction()
    // (action.js) connaît déjà, SANS inférence, la position réelle de action.roles qui a fourni
    // chaque argument -- transmise ici telle quelle, jamais recalculée depuis le texte/les tokens.
    const trace = await enregistrerTrace(e.magasin, {
      capacite: action.operation, voie: 'action', argumentsUtilises: invocation.arguments,
      provenanceArguments: provenanceTexte, resultat: invocation.resultat,
      contexte: { texteBrut: texte, tokens: tokeniser(texte) },
      provenancePositions: invocation.provenancePositions,
    });
    e.traces.push(trace);
    // v0.49 — POINT D'ORCHESTRATION COMMUN DU VÉCU (décision ChatGPT, 03/10/2026) : constate
    // seulement qu'une trace vient d'être persistée ({type:'trace', id}, rien de plus — voir
    // vecu.js). AUCUN consommateur n'est branché ici : volontairement neutre, voir l'en-tête de
    // vecu.js. N'affecte jamais le texte renvoyé ci-dessous.
    await apresNouveauVecu({ type: 'trace', id: trace.id });
    // v0.63 — DÉCISION CHATGPT « EXPOSER L'IDENTITÉ DE LA TRACE PRODUITE PAR UN TOUR » (03/10/2026) :
    // `idTrace` ajouté de façon STRICTEMENT ADDITIVE au retour -- la variable `trace` ci-dessus EST
    // déjà, par construction, la trace réellement persistée et poussée PENDANT ce tour (jamais une
    // recherche, jamais « la dernière » de e.traces) : CONSERVER son id, pas le RETROUVER. Reste
    // DORMANT : aucun consommateur ici, aucun effet sur traceExploitable()/possibilitesRejeuAdmissibles().
    return {
      reconnu: true, ok: true, texte: representerResultatAction(action, invocation.resultat), idTrace: trace.id,
    };
  }

  // === PREMIER REJEU AUTONOME (CHANTIER « PREMIER REJEU AUTONOME », décision ChatGPT) ==============
  // PREMIÈRE TENTATIVE D'INVOCATION ISSUE DU PROPRE VÉCU DE NAISSANCE, jamais d'une action enseignée.
  // N'est consultée par main.js QUE lorsque tenterReconnaissanceAction() ci-dessus a renvoyé
  // { reconnu: false } (aucune action enseignée validée ne correspond) -- CHEMIN A figé, aucune
  // concurrence enseigné/rejeu (section 2 du cadrage : marqueurs > transformation > action enseignée >
  // rejeu > pont conversationnel > Gemini). Consomme STRICTEMENT le résultat déjà pur de
  // possibilitesRejeuAdmissibles() (vue-traces.js, v0.60.1, le contrat désormais figé des primitives
  // v0.57-v0.60.1) : ne recalcule jamais une autre version de cette logique (section 1). Calculé AVANT
  // toute invocation et AVANT toute trace du présent tour, à partir des SEULES traces déjà présentes
  // dans e.traces (section 3) -- la trace que cette fonction peut créer plus bas ne peut donc jamais
  // influencer la décision qui vient de la produire.
  async function tenterRejeuAutonome(texte) {
    const e = await assurer();
    const { etat, possibilitesAdmissibles } = possibilitesRejeuAdmissibles(e.traces || [], texte);
    // 0/1/N (section 4) : AUCUN classement, AUCUNE préférence, AUCUN repli sur « la première
    // possibilité ». Seul l'état { unique }, avec défensivement EXACTEMENT une entrée, tente quoi que
    // ce soit ; { aucune } et { ambigu } sont une ABSTENTION SILENCIEUSE (section 16) -- le pipeline
    // conversationnel continue EXACTEMENT comme si cette fonction n'existait pas.
    if (etat !== 'unique' || possibilitesAdmissibles.length !== 1) return { reconnu: false };
    const possibilite = possibilitesAdmissibles[0];
    // GARDE DÉFENSIVE « CAPACITÉ DISPARUE » (section 6) : le pipeline pur l'exclut déjà normalement
    // (construireArgumentsPresents() filtre ce cas avant même la création d'une origine), mais entre
    // décision et invocation, aucune capacité absente du registre ACTUEL ne doit être appelée --
    // abstention propre, aucun résultat fabriqué, aucune trace.
    const capacite = CAPACITES[possibilite.capacite];
    if (!capacite) return { reconnu: false };
    // INVOCATION RÉELLE (section 5) : la MÊME capacité que les voies action/composition ci-dessus,
    // retrouvée EXCLUSIVEMENT via le registre CAPACITES -- jamais une deuxième implémentation métier,
    // jamais invoquerAction() (qui exigerait artificiellement un objet action enseignée : le rejeu est
    // une nouvelle voie d'accès à la MÊME capacité, pas une fausse action apprise). Les arguments sont
    // EXACTEMENT ceux de la possibilité admissible v0.60.1 (section 11), jamais recalculés, jamais
    // normalisés, jamais corrigés. Si la capacité lève, l'exception se propage ici SANS aucun nouveau
    // try/catch (section 14, même principe que tenterReconnaissanceAction()/invoquerAction()
    // ci-dessus) : aucune trace n'est créée après une invocation qui n'a pas retourné normalement.
    const resultat = capacite.invoquer(e, possibilite.arguments);
    // PROVENANCE DES ARGUMENTS (section 9) : chaque rôle réellement passé vient de cette nouvelle
    // voie, jamais 'texte'/'explicite'/'liaison', sans sous-catégorie non justifiée.
    const provenanceArguments = {};
    for (const role of Object.keys(possibilite.arguments)) provenanceArguments[role] = 'rejeu';
    // PROVENANCE POSITIONNELLE (section 10) : un objet complet UNIQUEMENT si TOUS les rôles de la
    // capacité possèdent une position convergente et valide (possibilite.positionsRoles couvre déjà,
    // par construction de v0.60.1, l'ensemble exact des rôles actuels de cette capacité) -- jamais un
    // mélange partiel, jamais une origine choisie arbitrairement ; sinon null, sans exception.
    let provenancePositions = null;
    if (possibilite.positionsRoles.length > 0
      && possibilite.positionsRoles.every((r) => r.etat === 'convergente' && typeof r.position === 'number')) {
      provenancePositions = {};
      for (const r of possibilite.positionsRoles) provenancePositions[r.role] = r.position;
    }
    // NOUVELLE VOIE « rejeu » (section 7), JAMAIS 'action' : traceExploitable() (vue-traces.js) reste
    // strictement inchangée, limitée à voie === 'action' -- cette trace est donc bien conservée comme
    // vécu, mais n'alimente aujourd'hui aucune future preuve de rejeu (aucune auto-catalyse, section
    // 18, voir les tests dédiés). CONTEXTE pré-choix (section 8) : le texte REÇU ici, avant toute
    // décision, exactement comme la voie action. RÉSULTAT brut (section 12) : conservé tel quel,
    // aucune interprétation succès/échec/récompense/confirmation/utilité.
    const trace = await enregistrerTrace(e.magasin, {
      capacite: possibilite.capacite, voie: 'rejeu', argumentsUtilises: possibilite.arguments,
      provenanceArguments, resultat,
      contexte: { texteBrut: texte, tokens: tokeniser(texte) },
      provenancePositions,
    });
    e.traces.push(trace);
    // POINT D'ORCHESTRATION COMMUN DU VÉCU (section 19) : exactement une fois, après persistance et
    // push de la trace, jamais avant l'invocation, jamais pour une abstention, jamais deux fois.
    await apresNouveauVecu({ type: 'trace', id: trace.id });
    // REPRÉSENTATION (section 15) : le MÊME adaptateur neutre que les voies action/composition --
    // aucun message « j'ai décidé seule », aucun changement cosmétique de personnalité. Le changement
    // est cognitif (une nouvelle voie d'invocation), pas expressif.
    // v0.63 — « EXPOSER L'IDENTITÉ DE LA TRACE PRODUITE PAR UN TOUR » : même principe exact que la
    // voie action ci-dessus -- `trace` est déjà la trace 'rejeu' réellement poussée, son id est
    // CONSERVÉ, jamais retrouvé. Reste dormant.
    return {
      reconnu: true, ok: true, texte: representerResultatAction({ operation: possibilite.capacite }, resultat), idTrace: trace.id,
    };
  }

  // === LIAISONS APPRISES (v0.43.0, décision ChatGPT « RÉFÉRENÇABILITÉ ET RÉUTILISATION SCALAIRE DES
  // RÉSULTATS ») ===================================================================================
  // PERSISTANCE D'UNE LIAISON DÉJÀ ÉVALUÉE (evaluerLiaison(), composition.js, PURE), PUIS confirmation
  // explicite de Christophe (« Valide la liaison. ») : même principe EXACT que confirmerAction()
  // ci-dessus. Recharge e.liaisons depuis le magasin, comme e.actions ci-dessus.
  async function confirmerLiaison(candidat) {
    const e = await assurer();
    const resultat = await apprendreLiaison(e.magasin, {
      capaciteSource: candidat.capaciteSource,
      champ: candidat.champ,
      capaciteCible: candidat.capaciteCible,
      role: candidat.role,
      origine: 'apprise-conversation',
    });
    e.liaisons = await e.magasin.lireTout('liaisons');
    await dessiner();
    return resultat;
  }

  // INVOCATION EXPLICITE D'UNE CAPACITÉ « AVEC LIAISONS » (composition.js, MÉCANISME 2) : TOUJOURS un
  // appel explicite (jamais une reconnaissance naturelle devinée, jamais déclenché par la simple
  // existence d'une liaison) -- voir composition.js pour la discipline complète. argumentsExplicites
  // vient ICI d'un bloc structurel explicite tapé par Christophe (« Compose : <opération> » suivi de
  // lignes « <rôle> : <valeur> »), jamais d'une phrase naturelle reconnue.
  async function invoquerComposition({ operation, argumentsExplicites }) {
    const e = await assurer();
    const invocation = invoquerAvecLiaisons(e, { operation, argumentsExplicites });
    if (!invocation.ok) {
      if (invocation.raison === 'operation_inconnue') return { ok: false, texte: `« ${operation} » n'est pas une opération interne autorisée.` };
      if (invocation.raison === 'role_non_resolu') {
        return {
          ok: false,
          texte: `Je ne peux pas composer : le rôle « ${invocation.detail.role} » n'est ni fourni explicitement, ni résolu par une liaison déjà apprise (${invocation.detail.raison}).`,
        };
      }
      return { ok: false, texte: `Je ne peux pas composer cette opération : ${invocation.raison}.` };
    }
    // v0.46 — OBSERVATION PASSIVE DES TENTATIVES DE RAISONNEMENT (même principe EXACT que dans
    // tenterReconnaissanceAction() ci-dessus, voie « composition » cette fois) : une capacité a
    // RÉELLEMENT été invoquée ICI, avec des arguments déjà résolus (explicites ET/OU liaisons, voir
    // invoquerAvecLiaisons()) -- on en conserve fidèlement une trace, rien de plus. AUCUNE trace n'est
    // créée quand la résolution d'un rôle échoue (branches ci-dessus, avant ce point) : une trace
    // n'existe QUE pour une invocation qui a réellement atteint la capacité.
    // v0.47 — CONTEXTE PRÉ-CHOIX, explicitement ABSENT ici (contexte: null) : « Compose: X » contient
    // déjà la capacité choisie dès sa première ligne — il n'existe structurellement AUCUN contexte
    // observable avant ce choix sur cette voie. Jamais un faux contexte reconstruit à partir du bloc
    // structurel (asymétrie entre les deux voies assumée, voir le rapport de diagnostic).
    // v0.53 — PROVENANCE POSITIONNELLE, explicitement ABSENTE ici (provenancePositions: null) :
    // cette voie n'a structurellement AUCUNE position textuelle source (arguments explicites tapés
    // directement, ou valeur résolue par liaison depuis le résultat d'une autre capacité -- jamais
    // une extraction depuis une position de texte), même asymétrie assumée que contexte: null
    // ci-dessus.
    const trace = await enregistrerTrace(e.magasin, {
      capacite: operation, voie: 'composition', argumentsUtilises: invocation.arguments,
      provenanceArguments: invocation.provenanceArguments, resultat: invocation.resultat,
      contexte: null,
      provenancePositions: null,
    });
    e.traces.push(trace);
    // v0.49 — POINT D'ORCHESTRATION COMMUN DU VÉCU (même principe EXACT que ci-dessus, voie
    // « action » : voir vecu.js, volontairement neutre pour 'trace' dans ce chantier).
    await apresNouveauVecu({ type: 'trace', id: trace.id });
    await dessiner();
    // Même adaptateur MINIMAL/NEUTRE que pour une invocation ordinaire (representerResultatAction,
    // action.js) -- il ne lit que action.operation, donc un simple objet { operation } suffit : aucune
    // action APPRISE (B1/B2, texte/squelette) n'est nécessaire pour cette invocation explicite.
    // v0.63 — « EXPOSER L'IDENTITÉ DE LA TRACE PRODUITE PAR UN TOUR » : même principe exact que les
    // voies action/rejeu ci-dessus. Reste dormant.
    return { ok: true, texte: representerResultatAction({ operation }, invocation.resultat), idTrace: trace.id };
  }

  // Exposés pour le pont conversationnel (main.js, v0.15) : UN SEUL esprit partagé entre le laboratoire et
  // la conversation — jamais une seconde copie de la base en mémoire. Deux fonctions déjà internes, non réécrites.
  return {
    rafraichir: dessiner, assurerEsprit: assurer, ecrireConnaissance,
    reconnaitreAttentesPourExperience,
    examinerPropositionSpontanee, confirmerPropositionSpontanee, refuserPropositionSpontanee,
    confirmerTransformation, appliquerTransformationLocale, tenterReconnaissanceTransformation,
    confirmerAction, tenterReconnaissanceAction,
    tenterRejeuAutonome,
    evaluerLiaison, confirmerLiaison, invoquerComposition,
    jugerExperience: async (idExperience, jugement) => {
      const e = await assurer();
      return confronterJugementEtEnregistrer(e.magasin, idExperience, jugement, e.lexique);
    },
    // v0.61.5 — « PREMIER BRANCHEMENT UI DE L'ACTE EXPLICITE » (décision ChatGPT, 03/10/2026) :
    // MÊME PRINCIPE EXACT que jugerExperience() ci-dessus -- une simple délégation vers la
    // primitive de persistance déjà construite (enregistrerActe(), connaissances.js, v0.61.4),
    // jamais une réimplémentation parallèle. L'origine est fixée ICI, en dur, à 'interface' : ce
    // premier branchement est le seul canal UI qui existe aujourd'hui, donc rien à choisir côté
    // appelant (main.js/conversation) -- jamais l'identité personnelle de Christophe. idTrace
    // n'est JAMAIS deviné ici : reçu tel quel depuis l'appelant (qui l'a lui-même reçu de la
    // bulle exacte, via fermeture -- voir conversation/ecran.js).
    enregistrerActeExplicite: async (idTrace) => {
      const e = await assurer();
      return enregistrerActe(e.magasin, { idTrace, origine: 'interface' });
    },
    // v0.62.0 — ÉTAPE 6 : MÊME PRINCIPE EXACT que enregistrerActeExplicite() ci-dessus -- une simple
    // délégation vers la primitive de persistance (enregistrerEnonceSurTrace(), connaissances.js),
    // origine fixée ICI à 'interface' (seul canal existant). idTrace et texte sont reçus tels quels de
    // l'appelant (main.js, via traiterTourAvecEnonce() de pont.js) : jamais devinés, jamais modifiés.
    // Aucun consommateur de la table 'enonces' nulle part.
    enregistrerEnonceSurTrace: async (idTrace, texte) => {
      const e = await assurer();
      return enregistrerEnonceSurTrace(e.magasin, { idTrace, texte, origine: 'interface' });
    },
    // Exposés pour « assimilation d'un cours » (v0.21, canal conversationnel main.js) : le MÊME
    // contexte {magasin, esprit, ecrire} que les boutons Vérifier/Confirmer du laboratoire
    // (contexteCours, déjà interne, non réécrit), et le même appelerGemini que « Demander un
    // enseignement à Gemini » -- aucun deuxième accès réseau, aucune deuxième vérification.
    // Enveloppé (jamais exposé null) pour rester une fonction même si aucun modèle externe n'est
    // configuré : l'appelant reçoit alors le même refus clair que le bouton laboratoire.
    contexteCours,
    appelerGemini: (args) => {
      if (!appelerGemini) throw new Error("Aucun professeur externe n'est disponible ici.");
      return appelerGemini(args);
    },
  };
}
// === FIN_LANGAGE_ECRAN ===
