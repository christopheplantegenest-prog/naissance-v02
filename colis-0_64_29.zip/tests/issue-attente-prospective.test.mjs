// v0.63.75 — issueDeLAttenteProspective : issue d'une attente prospective (décision ChatGPT, 08/10/2026). Preuves : vue pure sans table ; « avant » = attente figée seule, « après » =
// issueDuContexteProspectif du contexte référencé ; sans issue = rien de plus ; realisee / autre / absente par memesConstats ; conteneurs ; cas central ; identités (attendu X, réel
// Y) ; attente egale puis issue differente (attente inchangée) ; attente puis chemin absent ; attentes multiples confrontées séparément ; témoins conservés ; immutabilité ;
// scénario réel (28) et sonde (82) ; échec sans issue ; garde anti-sémantique ; dormance ; comportement vivant.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import * as module from '../app/langage/issue-attente-prospective.js';
import { issueDeLAttenteProspective, STATUTS_ATTENTE } from '../app/langage/issue-attente-prospective.js';
import { attentesDuContexteProspectif } from '../app/langage/attentes-prospectives.js';
import { contextesProspectifs } from '../app/langage/contexte-prospectif.js';
import { DESCRIPTIONS_OPERATIONS } from '../app/langage/descriptions-operations.js';
import { TABLE_OPERATIONS } from '../app/langage/table-operations.js';
import { executerApplicationsDeterminees } from '../app/langage/execution-mecanique.js';
import { executerApplicationSollicitee } from '../app/langage/execution-sollicitee.js';
import { suivreObservationDuTour } from '../app/langage/contexte-sollicitation.js';
import { traiterTourAvecEnonce } from '../app/langage/pont.js';
import { observerPossibilites } from '../app/langage/observation-possibilites.js';
import { magasinMemoireVive, enregistrerObservationPossibilites, enregistrerValeurDonnee, TABLES, VERSION_BASE } from '../app/langage/connaissances.js';
import { SCHEMA_SAUVEGARDE } from '../app/memoire/sauvegarde.js';
import { issuePlate } from './projection-attente.mjs'; // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : projection de vérification vers la forme .64.6 (scénarios B)

const RACINE = resolve(dirname(new URL(import.meta.url).pathname), '..');
const CHEMIN = join(RACINE, 'app', 'langage', 'issue-attente-prospective.js');
const SRC = readFileSync(CHEMIN, 'utf8');
const CODE = SRC.split('\n').filter((l) => !/^\s*\/\//.test(l)).join('\n');
const sansCommentaires = (s) => s.replace(/^\s*\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
const fichiersJs = (dir) => readdirSync(dir).flatMap((n) => { const p = join(dir, n); return statSync(p).isDirectory() ? fichiersJs(p) : /\.(m?js|html)$/.test(n) ? [p] : []; });
const refuse = (f) => assert.throws(f, (e) => e instanceof TypeError && /^(issueDeLAttenteProspective|rolesDeLAttente) : /.test(e.message)); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : une ligne illisible est refusée par la lecture des rôles
const TA = 'attentesProspectives'; const TC = 'contextesProspectifs';
const sk = (st) => st.map((s) => `${s.operation}(${s.entrees.join(',')})`).join('>');
const ch = { forme: 'scalaire', genre: 'chaine' };
const coll = { forme: 'collection', elements: ch };
const DESC = [{ nom: 'eclater', entrees: { x: ch }, sortie: coll }, { nom: 'recoller', entrees: { elements: coll }, sortie: ch }];
const DESC_NC = [DESC[0], { nom: 'recoller', entrees: { elements: coll }, sortie: { forme: 'quelconque' } }];
const msg = (id, valeur) => ({ id, valeur });
const lien = (entree, donnee) => ({ entree, donnee });
let seq = 0;
const h = () => `2026-10-08T06:00:${String(++seq).padStart(2, '0')}.000Z`;
const ex = (id, operation, liaisons, resultat, idDesignation = `d-${id}`) => ({ id, horodatage: h(), idDesignation, operation, liaisons, resultat });
// Monde synthétique : n expériences passées (issues[k] = valeur d'arrivée de S_k ; défaut v_k = retour), contextes et attentes écrits « au fil de l'eau » ;
// le contexte courant est c{n+1}-p et son issue S_{n+1} vaut `courante` (par défaut v_{n+1}) ; sans `courante` === null, aucune exécution courante.
function monde(n, { issues = [], courante, desc = DESC } = {}) {
  seq = 0;
  const M = []; const E = []; const contextes = []; const attentes = []; let numero = 0;
  let designation = null;
  for (let k = 1; k <= n + 1; k += 1) {
    M.push(msg(`m${k}`, `v${k}`));
    E.push(ex(`R${k}`, 'eclater', [lien('x', `m${k}`)], ['v', String(k)]));
    designation = { id: `d-S${k}`, horodatage: h(), idObservation: `o${k}`, operation: 'recoller', liaisons: [lien('elements', `R${k}`)] };
    const nouveaux = contextesProspectifs({ operation: 'recoller', liaisons: [lien('elements', `R${k}`)] }, M, E, desc).map((c) => ({ id: `c${k}-${c.parent ? 'p' : 'd'}`, horodatage: h(), idDesignation: `d-S${k}`, idObservation: `o${k}`, ...c }));
    contextes.push(...nouveaux);
    for (const c of nouveaux) for (const a of attentesDuContexteProspectif(c, designation, contextes, M, E, desc)) attentes.push({ id: `a${++numero}`, horodatage: h(), idObservation: `o${k}`, ...a });
    if (k <= n) E.push(ex(`S${k}`, 'recoller', [lien('elements', `R${k}`)], issues[k - 1] === undefined ? `v${k}` : issues[k - 1], `d-S${k}`));
  }
  if (courante !== null) E.push(ex(`S${n + 1}`, 'recoller', [lien('elements', `R${n + 1}`)], courante === undefined ? `v${n + 1}` : courante, `d-S${n + 1}`));
  const courant = contextes.find((c) => c.id === `c${n + 1}-p`);
  return { M, E, contextes, attentes, courant, desc, miennes: attentes.filter((a) => a.references.idContexte === `c${n + 1}-p`) }; // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
}
const issueDe = (w, a) => issueDeLAttenteProspective(a, w.contextes.find((c) => c.id === a.references.idContexte), w.M, w.E, w.desc); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
const ligneDe = (w, nom) => w.miennes.find((a) => a.description.chemin.join('.') === nom);
const parChemin = (w, nom) => issueDe(w, ligneDe(w, nom));

// ---------------------------------------------------------------------------------------------------------------------------------- A. CONTRAT
test('A1. exports : issueDeLAttenteProspective (5 paramètres, synchrone), STATUTS_ATTENTE = realisee / autre / absente ; garde anti-sémantique ; imports exacts ; aucune table', () => {
  assert.deepEqual(Object.keys(module).sort(), ['STATUTS_ATTENTE', 'issueDeLAttenteProspective', 'issuesDeLAttenteProspective']); // MISE À JOUR DÉLIBÉRÉE v0.63.96 (pluralité des issues) : + le pluriel ; le singulier garde son nombre de paramètres obligatoires (ancre idExecution facultative)
  assert.equal(issueDeLAttenteProspective.length, 5);
  assert.equal(issueDeLAttenteProspective.constructor.name, 'Function');
  assert.deepEqual(STATUTS_ATTENTE, ['realisee', 'autre', 'absente']);
  assert.equal(Object.isFrozen(STATUTS_ATTENTE), true);
  assert.equal(/relationValeur|egale|differente|arrivee|'execution'|'vers'|symbolesDeChaine|composerCollection|'valeurs'|'depart'/.test(CODE), false);
  assert.equal(/reussite|réussite|echec|échec|recompense|récompense|punition|confiance|score|probab|majorit|vote|\bDate\b|Math\.random|\bawait\b|\basync\b|magasin|\.ecrire|\.lireTout/i.test(CODE), false);
  const importees = [...SRC.matchAll(/^import .* from '(.+)';$/gm)].map((m) => m[1]).sort();
  assert.deepEqual(importees, ['./constats-structurels.js', './couverture-occurrences.js', './issue-contexte-prospectif.js', './roles-attente.js']); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : la ligne est lue par rôles
  assert.equal(/Object\.is|parcourirStructure|episodesDeTransformation/.test(CODE), false, 'aucune sémantique parallèle : l\'issue du contexte et memesConstats');
  assert.equal(VERSION_BASE, 29); assert.equal(SCHEMA_SAUVEGARDE, 19); assert.equal(TABLES.length, 35); // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 21 → 22 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 11 → 12 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.80 (J-A, émissions/réceptions) : 24 → 26 (+ tables emissions, receptions : VERSION_BASE 22, SCHEMA_SAUVEGARDE 12, 26 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.84 (B1, capacité d'agir) : + capaciteInitiale, variationsCapacite (VERSION_BASE 23, SCHEMA_SAUVEGARDE 13, 28 tables) // MISE À JOUR DÉLIBÉRÉE v0.63.86 (B2, état relationnel) : + relationInitiale, variationsRelation (VERSION_BASE 24, SCHEMA_SAUVEGARDE 14, 30 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 24 → 25 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 14 → 15 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables) // MISE À JOUR DÉLIBÉRÉE — v0.64.14 : 30 → 31 (+ table manifestationsFaits : VERSION_BASE 25, SCHEMA_SAUVEGARDE 15, 31 tables) // MISE À JOUR DÉLIBÉRÉE v0.64.17 : 25 → 26 / 15 → 16 / 31 → 32 (+ table decisionsFormes : VERSION_BASE 26, SCHEMA_SAUVEGARDE 16, 32 tables) // MISE À JOUR DÉLIBÉRÉE v0.64.19 : + table reponsesAttendues (VERSION_BASE 27, SCHEMA_SAUVEGARDE 17, 33 tables) // MISE À JOUR DÉLIBÉRÉE v0.64.22 : + table reponsesLocales (VERSION_BASE 28, SCHEMA_SAUVEGARDE 18, 34 tables) // MISE À JOUR DÉLIBÉRÉE v0.64.25 : + table actesResolution (VERSION_BASE 29, SCHEMA_SAUVEGARDE 19, 35 tables)
});

test('A2. SANS ISSUE : aucune exécution pour idDesignation -> issue null, l\'attente recopiée (constat, témoins, unités), ni statut ni reel', () => {
  const w = monde(2, { courante: null });
  const r = parChemin(w, 'relationValeur');
  assert.deepEqual(Object.keys(r), ['idAttente', 'references', 'description', 'issue']); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : description + références, plus aucune preuve dans l'issue
  assert.deepEqual(Object.keys(r.description), ['structure', 'chemin', 'constat']); assert.deepEqual(Object.keys(r.references), ['idContexte', 'idDesignation']);
  assert.equal(r.issue, null);
  assert.deepEqual(r.description.constat, { type: 'chaine', valeur: 'egale' });
  const ligne = ligneDe(w, 'relationValeur'); // la preuve reste lisible dans la ligne persistée
  assert.deepEqual(ligne.preuve.unitesIssues, [['c2-p', 'S2', 'relationValeur']]); // MISE À JOUR DÉLIBÉRÉE v0.63.96 (pluralité des issues) : identité d'unité uniforme [idContexte, idExecution, …chemin] (contexte × conséquence × chemin)
  assert.equal(ligne.preuve.temoinsContexte.length, 2);
});

test('A3. REALISEE : chemin présent, constat réel = constat engagé (memesConstats) ; le réel est conservé même identique ; conteneur { objet } confronté pareil', () => {
  const w = monde(2);
  const rel = parChemin(w, 'relationValeur');
  assert.equal(rel.statut, 'realisee'); assert.deepEqual(rel.description.constat, { type: 'chaine', valeur: 'egale' }); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) assert.deepEqual(rel.reel, { type: 'chaine', valeur: 'egale' });
  assert.deepEqual(rel.issue, { idExecution: 'S3' });
  assert.deepEqual(Object.keys(rel), ['idAttente', 'references', 'description', 'issue', 'statut', 'reel']); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.equal(w.miennes.some(({ description: { chemin } }) => chemin[0] === 'valeurs' && chemin.length < 3 && chemin[1] !== 'arrivee'), false); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
  const direct = w.attentes.find((a) => a.references.idContexte === 'c3-d' && a.description.chemin.join('.') === 'valeurs');
  const val = issueDe(w, direct);
  assert.equal(val.statut, 'realisee'); assert.deepEqual(val.description.constat, { type: 'objet' }); assert.deepEqual(val.reel, { type: 'objet' });
});

test('A4. AUTRE : attentes d\'identité (attendu S2, réel S3) et de valeur (attendu v2, réel v3) : chemin présent, constat réel différent ; attendu figé et réel conservés, pas de booléen', () => {
  const w = monde(2);
  for (const nom of ['arrivee', 'chemin.1.execution', 'chemin.1.vers']) { const r = parChemin(w, nom); assert.equal(r.statut, 'autre'); assert.deepEqual(r.description.constat, { type: 'chaine', valeur: 'S2' }); assert.deepEqual(r.reel, { type: 'chaine', valeur: 'S3' }); }
  for (const nom of ['valeurs.arrivee']) { const r = parChemin(w, nom); assert.equal(r.statut, 'autre'); assert.deepEqual(r.description.constat, { type: 'chaine', valeur: 'v2' }); assert.deepEqual(r.reel, { type: 'chaine', valeur: 'v3' }); }
  assert.equal(w.miennes.length, 5); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
  const statuts = w.miennes.map((a) => issueDe(w, a).statut);
  assert.deepEqual(statuts.filter((s) => s === 'realisee').length, 1); assert.deepEqual(statuts.filter((s) => s === 'autre').length, 4);
});

test('A5. ATTENTE egale PUIS ISSUE differente : attendu egale, réel differente, statut autre ; l\'attente persistée est inchangée', () => {
  const w = monde(4, { courante: 'autre' });
  const avant = structuredClone(w.miennes);
  const rel = parChemin(w, 'relationValeur');
  assert.deepEqual(rel.description.constat, { type: 'chaine', valeur: 'egale' }); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.deepEqual(rel.reel, { type: 'chaine', valeur: 'differente' });
  assert.equal(rel.statut, 'autre');
  assert.deepEqual(ligneDe(w, 'relationValeur').preuve.unitesIssues.map((u) => u[0]), ['c2-p', 'c3-p', 'c4-p']);
  assert.deepEqual(w.miennes, avant);
  assert.deepEqual(w.miennes.map((a) => a.description.chemin.join('.')), ['relationValeur'], 'seule attente du contexte prolongé'); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
});

test('A6. ATTENTE PUIS CHEMIN ABSENT : arrivée non comparable -> le chemin valeurs.arrivee n\'existe pas -> absente, sans reel, sans pseudo-constat (v0.63.97 : valeurs et valeurs.depart restent)', () => {
  const w = monde(3, { desc: DESC_NC, issues: ['x', 'x', 'x'], courante: ['pas', 'comparable'] }); // MISE À JOUR DÉLIBÉRÉE v0.63.97 : arrivées passées identiques (« x ») pour qu'une attente sur valeurs.arrivee existe ; c'est elle qui devient absente
  const val = parChemin(w, 'valeurs.arrivee'); // MISE À JOUR DÉLIBÉRÉE v0.63.97 (découplage des valeurs) : l'arrivée non comparable n'efface plus `valeurs` (le départ comparable garde valeurs.depart) ; l'absence porte désormais sur valeurs.arrivee
  assert.equal(val.statut, 'absente');
  assert.equal('reel' in val, false);
  assert.deepEqual(val.description.constat, { type: 'chaine', valeur: 'x' }); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.deepEqual(val.issue, { idExecution: 'S4' });
  assert.equal(w.miennes.some((a) => a.description.chemin.join('.') === 'valeurs'), false, 'le conteneur est déjà connu : aucune attente'); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
  assert.equal(JSON.stringify(val).includes('ABSENT'), false);
  assert.equal(parChemin(w, 'relationValeur').statut, 'autre', 'non_comparable au lieu de egale : autre, pas absente');
  assert.deepEqual(parChemin(w, 'relationValeur').reel, { type: 'chaine', valeur: 'non_comparable' });
});

test('A7. entrées mal formées et ancrage brisé : TypeError, aucun résultat partiel', () => {
  const w = monde(2);
  const [a] = w.miennes;
  const c = w.contextes.find((x) => x.id === a.references.idContexte); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  const dans = (role, champ, valeur) => ({ ...a, [role]: { ...a[role], [champ]: valeur } });
  refuse(() => issueDeLAttenteProspective(null, c, w.M, w.E, DESC));
  refuse(() => issueDeLAttenteProspective({ ...a, id: '' }, c, w.M, w.E, DESC));
  refuse(() => issueDeLAttenteProspective(dans('description', 'constat', { valeur: 'x' }), c, w.M, w.E, DESC));
  refuse(() => issueDeLAttenteProspective(dans('description', 'chemin', 'x'), c, w.M, w.E, DESC));
  refuse(() => issueDeLAttenteProspective({ ...a, constat: a.description.constat }, c, w.M, w.E, DESC), 'forme mêlée : refusée');
  refuse(() => issueDeLAttenteProspective(dans('preuve', 'constat', a.description.constat), c, w.M, w.E, DESC), 'donnée au mauvais rôle');
  refuse(() => issueDeLAttenteProspective(a, w.contextes.find((x) => x.id === 'c3-d'), w.M, w.E, DESC), 'autre contexte');
  refuse(() => issueDeLAttenteProspective(a, { ...c, idDesignation: 'd-autre' }, w.M, w.E, DESC));
  refuse(() => issueDeLAttenteProspective(dans('description', 'chemin', ['inconnu']), c, w.M, w.E, DESC), 'chemin qui n\'était pas ouvert');
});

test('A8. IMMUTABILITÉ et pureté : expériences ajoutées après l\'issue -> même issue ; entrées gelées intactes ; sorties neuves', () => {
  const w = monde(3);
  const avant = w.miennes.map((a) => issueDe(w, a));
  // le monde continue : trois expériences de plus, dont une differente
  const w2 = monde(6, { issues: ['v1', 'v2', 'v3', 'v4', 'autre', 'v6'] });
  const memes = w.miennes.map((a) => issueDeLAttenteProspective(a, w.contextes.find((c) => c.id === a.references.idContexte), w2.M, w2.E, DESC));
  assert.deepEqual(memes, avant);
  const gel = (o) => { if (o && typeof o === 'object') { Object.values(o).forEach(gel); Object.freeze(o); } return o; };
  const a = gel(structuredClone(w.miennes[0])); const c = gel(structuredClone(w.contextes.find((x) => x.id === a.references.idContexte))); const M = gel(structuredClone(w.M)); const E = gel(structuredClone(w.E));
  const fige = JSON.stringify([a, c, M, E]);
  const r1 = issueDeLAttenteProspective(a, c, M, E, DESC); const r2 = issueDeLAttenteProspective(a, c, M, E, DESC);
  assert.deepEqual(r1, r2); assert.notEqual(r1, r2); assert.equal(r1.description.constat === a.description.constat, false); assert.equal(r1.description.chemin === a.description.chemin, false); assert.equal('preuve' in r1, false); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.equal(JSON.stringify([a, c, M, E]), fige);
});

// ---------------------------------------------------------------------------------------------------------------------------------- B. FLUX RÉEL
let compteurIds = 0;
async function rejouer(scenario, magasin = magasinMemoireVive(), solliciter = false) {
  const nouvelId = (p) => `${p}-${++compteurIds}`;
  const tours = []; const ex2 = () => magasin.lireTout('executionsOperations');
  for (const t of scenario) {
    const suivi = suivreObservationDuTour((m) => observerPossibilites(m, { enregistrer: (d) => enregistrerObservationPossibilites(magasin, d), lireExecutions: ex2 }), (c) => executerApplicationsDeterminees(c, { magasin, table: TABLE_OPERATIONS }));
    const res = await traiterTourAvecEnonce(t, null, { enregistrerEnonce: async () => {}, traiter: async () => ({ texte: 'ok' }), nouvelId, observerPossibilites: suivi.observer, enregistrerValeur: (e) => enregistrerValeurDonnee(magasin, e) });
    const s = suivi.joindre(res).sollicitation; tours.push(s);
    if (solliciter) {
      const { observation, univers } = s; const vals = await magasin.lireTout('valeursDonnees'); const msgId = vals[vals.length - 1].id; const faits = await ex2();
      const soll = async (operation, liaisons) => { const r = await executerApplicationSollicitee({ observation, application: { operation, liaisons }, univers }, { magasin, table: TABLE_OPERATIONS }); assert.equal(r.statut, 'executee'); };
      for (const R of faits.filter((e) => e.operation === 'symbolesDeChaine')) if (!faits.some((e) => e.operation === 'composerCollection' && e.liaisons[0].donnee === R.id) && observation.donneesExaminees.includes(R.id)) await soll('composerCollection', [lien('elements', R.id)]);
      if (!(await ex2()).some((e) => e.operation === 'symbolesDeChaine' && e.liaisons[0].donnee === msgId)) await soll('symbolesDeChaine', [lien('chaine', msgId)]);
    }
  }
  const valeurs = await magasin.lireTout('valeursDonnees'); const executions = await ex2(); const contextes = await magasin.lireTout(TC); const attentes = await magasin.lireTout(TA);
  const issues = attentes.map((a) => issuePlate(issueDeLAttenteProspective(a, contextes.find((c) => c.id === a.references.idContexte), valeurs, executions, DESCRIPTIONS_OPERATIONS), a)); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente) : lecture par projection plate (même information)
  return { tours, magasin, valeurs, executions, contextes, attentes, issues };
}
const SCENARIO = ['bonjour Pixel', 'bonjour Luna', 'bonjour Pixel', 'bonjour Max', 'bonjour Pixel et Luna', 'au revoir Pixel', 'bonjour Luna'];
const compter = (issues) => issues.reduce((c, i) => { c[i.issue ? i.statut : 'sansIssue'] += 1; return c; }, { realisee: 0, autre: 0, absente: 0, sansIssue: 0 });
const ventiler = (issues) => { const v = {}; for (const i of issues) { if (!i.issue) continue; const k = i.chemin.join('.'); v[k] = v[k] ?? { realisee: 0, autre: 0, absente: 0 }; v[k][i.statut] += 1; } return v; };

test('B1. SCÉNARIO RÉEL (MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chaque message est traité ; .93 : 0 attente ; .92 : 28) : 70 attentes, 70 issues (46 realisee, 24 autre, 0 absente, 0 sans issue) ; seules les applications NOUVELLES sont exécutées. Mécanisme détaillé couvert par B2 ', async () => {
  const { tours, executions, issues } = await rejouer(SCENARIO);
  assert.deepEqual(tours.map((s) => s.choixAFaire.length), [0, 1, 5, 13, 13, 13, 13]); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  assert.deepEqual(tours.map((s) => s.automatiques.length), [2, 5, 10, 3, 3, 3, 3]); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  assert.equal(executions.length, 29); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation)
  assert.equal(tours.flatMap((s) => s.automatiques).filter((x) => x.statut !== 'executee').length, 0);
  assert.equal(issues.length, 70); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation) // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.deepEqual(compter(issues), { realisee: 46, autre: 24, absente: 0, sansIssue: 0 }); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : mesuré // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
});

test('B2. SONDE SIX EXPÉRIENCES : 90 attentes (MISE À JOUR DÉLIBÉRÉE v0.63.94 : 82 avant la causalité locale) ; structure centrale : relationValeur egale realisee ×4 (témoins figés 2/1 … 5/4), valeurs objet realisee ×4, identités et valeurs futures autre ×1 chacune', async () => {
  const { issues } = await rejouer(['bonjour Pixel', 'bonjour Luna', '', 'abc', 'é😀', 'éa', 'fin'], undefined, true);
  assert.equal(issues.length, 90); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : chiffres mesurés ; chaque message est désormais traité (symbolesDeChaine et parcourirStructure déterminées relativement à l’observation) // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.deepEqual(compter(issues), { realisee: 58, autre: 32, absente: 0, sansIssue: 0 }); // MISE À JOUR DÉLIBÉRÉE v0.63.94 — CAUSALITÉ LOCALE : mesuré // MISE À JOUR DÉLIBÉRÉE v0.63.97 — DÉCOUPLAGE DES VALEURS D’ÉPISODE : chiffres mesurés ; chaque extrémité comparable porte sa valeur, de nouveaux chemins valeurs.* deviennent observables // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  const centrales = issues.filter((i) => sk(i.structure) === 'symbolesDeChaine(chaine)>composerCollection(elements)');
  assert.equal(centrales.length, 8); // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  assert.deepEqual(ventiler(centrales), { arrivee: { realisee: 0, autre: 1, absente: 0 }, 'chemin.1.execution': { realisee: 0, autre: 1, absente: 0 }, 'chemin.1.vers': { realisee: 0, autre: 1, absente: 0 }, relationValeur: { realisee: 4, autre: 0, absente: 0 }, 'valeurs.arrivee': { realisee: 0, autre: 1, absente: 0 } }); // MISE À JOUR DÉLIBÉRÉE v0.64.0 — CHEMINS OUVERTS DE L’ÉPISODE PRÉSENT : chiffres mesurés ; plus aucune attente sur un chemin déjà connu dans la partie connue (valeurs, valeurs.depart)
  const rel = centrales.filter((i) => i.chemin[0] === 'relationValeur');
  assert.deepEqual(rel.map((i) => `${i.temoinsContexte.length}/${i.unitesIssues.length}`), ['2/1', '3/2', '4/3', '5/4']);
  for (const i of rel) { assert.deepEqual(i.constat, { type: 'chaine', valeur: 'egale' }); assert.deepEqual(i.reel, { type: 'chaine', valeur: 'egale' }); }
  const vd = centrales.find((i) => i.chemin.join('.') === 'valeurs.arrivee'); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
  assert.deepEqual(vd.constat, { type: 'chaine', valeur: 'bonjour Luna' }); assert.deepEqual(vd.reel, { type: 'chaine', valeur: '' });
  assert.equal(centrales.some((i) => i.chemin.join('.') === 'valeurs.depart'), false, 'plus d’attente sur le départ déjà connu');
  // une même exécution (T4) : realisee pour relationValeur et valeurs, autre pour identités et valeurs futures : jamais agrégé
  const t4 = centrales.filter((i) => i.idDesignation === vd.idDesignation);
  assert.deepEqual(t4.map((i) => i.statut).sort(), ['autre', 'autre', 'autre', 'autre', 'realisee']); // MISE À JOUR DÉLIBÉRÉE v0.64.0 (chemins ouverts de l'épisode présent) : `valeurs` et valeurs.depart sont déjà connus pour le contexte prolongé (départ m_k comparable) : plus d'attente sur eux ; le conteneur reste attendu sur le contexte direct (départ collection)
});

test('B3. ÉCHEC APRÈS ATTENTE (cas .74) : attentes écrites, invocation qui lève, aucune exécution -> issue null pour chacune', async () => {
  const { tours, magasin } = await rejouer(['bonjour Pixel', 'bonjour Luna', 'bonjour Pixel', 'bonjour Max']);
  const { observation, univers } = tours[3];
  const message = (await magasin.lireTout('valeursDonnees')).at(-1);
  const panne = { ...TABLE_OPERATIONS, symbolesDeChaine: { ...TABLE_OPERATIONS.symbolesDeChaine, fonction: () => { throw new Error('panne volontaire'); } } };
  const r = await executerApplicationSollicitee({ observation, application: { operation: 'symbolesDeChaine', liaisons: [lien('chaine', message.id)] }, univers }, { magasin, table: panne });
  assert.equal(r.statut, 'echec_invocation');
  const V = await magasin.lireTout('valeursDonnees'); const E = await magasin.lireTout('executionsOperations'); const C = await magasin.lireTout(TC);
  const miennes = (await magasin.lireTout(TA)).filter((a) => a.references.idDesignation === r.designation.id); // MISE À JOUR DÉLIBÉRÉE v0.64.7 (rôles de l'attente)
  assert.ok(miennes.length > 0);
  for (const a of miennes) { const i = issueDeLAttenteProspective(a, C.find((c) => c.id === a.references.idContexte), V, E, DESCRIPTIONS_OPERATIONS); assert.equal(i.issue, null); assert.equal('statut' in i, false); }
});

const sansPontDiagnostic = (code) => { const i = code.indexOf('attentesConditionnees: async () => {'); const j = code.indexOf('return relireIssuesAujourdhui(', i); return i < 0 || j < 0 ? code : code.slice(0, i) + code.slice(code.indexOf('\n', j)); }; // MISE À JOUR DÉLIBÉRÉE v0.64.28 : le pont Diagnostic de main.js (attentesConditionnees / issuesAujourdhui, lecture seule à l'ouverture de sa section) est retiré du code examiné, et seulement lui ; son contenu est gardé par tests/attentes-conditionnees-persistees.test.mjs
const LECTURE_RECONNAISSANCE = "if (conditionnee) reconnaissance = formulationsAnterieures({ description, preuve, references }, await magasin.lireTout('attentesProspectives'));"; // MISE À JOUR DÉLIBÉRÉE v0.64.29 (reconnaître une relation déjà formulée, GO ChatGPT du 16/10/2026) : la SEULE lecture de la table par un mécanisme, dans enregistrerAttenteProspective, après les garanties d'ordre et avant l'unique écriture d'une attente conditionnée ; bornée par tests/relations-formulees.test.mjs
const sansLectureReconnaissance = (code) => code.split('\n').filter((l) => l.trim() !== LECTURE_RECONNAISSANCE).join('\n');
test('B4. DORMANCE : aucun fichier de app/ n\'importe ni ne nomme la vue ; aucun mécanisme ne lit les attentes ; catalogue et table inchangés', () => {
  for (const f of fichiersJs(join(RACINE, 'app'))) {
    if (f === CHEMIN) continue;
    if (f === join(RACINE, 'app', 'langage', 'attentes-du-tour.js')) continue; // MISE À JOUR DÉLIBÉRÉE v0.63.78 (jalon 1) : attentes-du-tour.js (présentation, lecture seule) appelle la vue pour afficher l'issue de chaque attente du lot dans la zone de développement ; aucune décision.
    if (f === join(RACINE, 'app', 'langage', 'confrontations-attentes.js')) continue; // MISE À JOUR DÉLIBÉRÉE v0.64.8 (confrontation comme unité du vécu) : confrontations-attentes.js (vue pure dormante) compose la vue plurielle pour dériver les confrontations [attente, conséquence] ; elle-même non branchée
    if (f === join(RACINE, 'app', 'langage', 'attentes-conditionnees-persistees.js')) continue; // MISE À JOUR DÉLIBÉRÉE v0.64.28 (autorisée par le GO) : vue Diagnostic en lecture seule des attentes conditionnées persistées ; elle délègue la relecture de l'issue, sur geste explicite, à issuesDeLAttenteProspective ; seul lecteur : le pont Diagnostic de main.js
    if (f === join(RACINE, 'app', 'langage', 'experiences-attentes.js')) continue; // MISE À JOUR DÉLIBÉRÉE v0.63.76 : experiences-attentes.js (vue pure dormante) compose cette vue pour présenter les issues d'attentes comme expériences : seul importeur, lui-même non branché
    assert.equal(/issue-attente-prospective|issueDeLAttenteProspective|STATUTS_ATTENTE/.test(readFileSync(f, 'utf8')), false, f);
  }
  for (const autre of ['sw.js', 'worker.js', 'index.html']) { let s = ''; try { s = readFileSync(join(RACINE, autre), 'utf8'); } catch { continue; } assert.equal(/issue-attente-prospective/.test(s), false, autre); }
  for (const f of fichiersJs(join(RACINE, 'app'))) if (f !== join(RACINE, 'app', 'langage', 'attentes-du-tour.js')) assert.equal(/lireTout\(\s*['"]attentesProspectives/.test(sansLectureReconnaissance(sansPontDiagnostic(sansCommentaires(readFileSync(f, 'utf8'))))), false, f); // MISE À JOUR DÉLIBÉRÉE v0.64.28 (autorisée par le GO) : + le seul pont Diagnostic de main.js (sansPontDiagnostic) // MISE À JOUR DÉLIBÉRÉE v0.63.78 (jalon 1) : seule exception : attentes-du-tour.js (présentation, lecture seule)
  assert.equal(DESCRIPTIONS_OPERATIONS.length, 17); assert.equal(Object.keys(TABLE_OPERATIONS).length, 17);
});
